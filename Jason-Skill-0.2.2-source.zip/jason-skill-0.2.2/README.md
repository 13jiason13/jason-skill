# Jason Skill

A Codex skill for verified file, browser, and desktop workflows on macOS and Windows. It selects an appropriate interface for the task, batches compatible actions, and checks the actual result.

## Install

Download the single-file installer from the [release page](https://github.com/13jiason13/jason-skill/releases). Verify its SHA-256, attach the TXT file to a Codex environment with local file and terminal access, and ask:

> Install Jason Skill and configure the desktop and browser tools I need.

Python 3.8 or later is required. On Windows, use `py -3` where the examples use `python3`. The default skill directory is `~/.agents/skills/jason-skill`; an existing installation can use `--skills-root` to select its current host directory.

From the extracted source archive:

```sh
python3 tools/build_bundle.py
python3 tools/install_bundle.py dist/Jason-Skill-0.2.2-install.txt
```

Invoke `$jason-skill` after installation. Open a new conversation if the host has not refreshed its skill list.

## Capabilities

| Task | Route | Verification |
| --- | --- | --- |
| Find, edit, organize, and archive files | Host file tools, terminal, or application APIs | Read the saved file and check its destination |
| Read pages, fill forms, and submit information | Isolated browser or agent-browser | Check the page state and submission result |
| Read windows, click, type, check controls, and save | Host Computer Use, agent-desktop, or optional Cua Driver | Read the application model and persisted output |
| Operate canvases or authorized remote consoles | Available visual desktop tools; SSH when suitable | Confirm the target and actual response |
| Configure a new machine and diagnose missing tools | Bundled environment and setup scripts | Report installation, connection, permission, and acceptance separately |

## Configure the toolchain

Reuse tools already connected to the host. The installer can also fetch pinned official command-line releases into a dedicated user directory.

```sh
python3 ~/.agents/skills/jason-skill/scripts/doctor.py
python3 ~/.agents/skills/jason-skill/scripts/setup_all.py
python3 ~/.agents/skills/jason-skill/scripts/setup_all.py --apply
```

Add `--browser-runtime` to install Chrome for Testing through agent-browser. Add `--include-cua` to configure optional Cua Driver on macOS or Windows. Add `--pinned` to install the distribution's pinned versions in their dedicated directories while preserving existing programs. The report returns full executable paths.

- [agent-browser](https://github.com/vercel-labs/agent-browser) 0.43.0 provides browser automation.
- [agent-desktop](https://github.com/vercel-labs/agent-desktop) 1.3.1 provides native accessibility operations.
- [Cua Driver](https://github.com/trycua/cua/releases/tag/cua-driver-rs-v0.55.0) 0.55.0 is an optional additional desktop route.

Windows x64 has native browser and desktop assets. Windows ARM64 has a native desktop asset. Windows 11 ARM may use the x64 browser asset through OS emulation, subject to a runtime and page test. Windows 10 ARM can use an existing host-supported browser.

System permissions and third-party sign-ins are completed on the recipient's computer. See the [portable installation guide](skills/jason-skill/references/portable-install.md).

## Scripts

| Script | Purpose |
| --- | --- |
| `tools/build_bundle.py` | Build the readable single-file installer and integrity manifest from an explicit file list |
| `tools/install_bundle.py` | Validate and install the skill, protect existing content, and back up and roll back updates |
| `scripts/doctor.py` | Read-only platform, architecture, Python, and dependency detection |
| `scripts/setup_all.py` | One setup entry point for desktop and browser routes |
| `scripts/setup_tools.py` | Fetch pinned official CLI assets, verify SHA-256, and check executable versions |
| `scripts/setup_macos.py` | Optional signed macOS Cua installation and machine-specific MCP configuration |
| `scripts/setup_windows.py` | Optional native Windows Cua installation and machine-specific MCP configuration |
| `benchmarks/parity/` | Equivalent native test forms and persisted-output checks for macOS and Windows |

## Verification and compatibility

Run `python3 -m unittest discover -s tests -v`. The current local run passed 27 tests. The workflow is configured to run installer tests on Linux, macOS, and Windows after the source workflow is uploaded.

On one Intel Mac running macOS 14.8.9, the local Cua 0.55.0 compatibility build passed background read, click, text entry, checkbox, save, and persisted-file verification. The public installer uses official binaries. The optional source patch and its provenance are included under `patches/`.

Windows GUI acceptance, Windows ARM browser emulation, other target applications, and cross-machine performance remain unverified. Use the [shared acceptance procedure](benchmarks/parity/README.md) on each machine. Historical driver timings are documented in the [benchmark scope](skills/jason-skill/references/benchmark.md).

## License and privacy

Jason Skill source is distributed under the [MIT License](LICENSE). Third-party tools are downloaded from their upstream projects and retain their own licenses. The package excludes publisher accounts, browser profiles, credentials, remote-server configuration, and system grants. See [SECURITY.md](SECURITY.md).
