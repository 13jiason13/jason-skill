# Jason Skill

Jason Skill 给 Codex 一套操作本机的工作流。根据任务选择终端、服务接口、隔离浏览器或桌面驱动，操作后用文件、页面状态或应用数据验收。源码使用 MIT 许可证，第三方工具从各自的官方源安装。

## 安装

**单文件方式。** 下载 `dist/jason skill-0.2.2-拖入Codex安装.txt`，拖入有本机文件和终端权限的 Codex，发送「安装 Jason Skill，并配置我需要的桌面和网页工具」。需要 Python 3.8+。初次安装的目录默认是 `~/.agents/skills/jason-skill`，已有不同版本时先查看差异再更新。系统的辅助功能、录屏和登录授权由接收者在本机完成。

**从源码安装。**

```sh
python3 tools/build_bundle.py
python3 tools/install_bundle.py "dist/jason skill-0.2.2-拖入Codex安装.txt"
```

Windows 可用 `py -3` 替换 `python3`。安装后在 Codex 调用 `$jason-skill`。如果宿主还没发现新 Skill，可新开聊天或重启宿主。

## 功能与工具

| 要做什么 | 工具 | 实际怎么验收 |
| --- | --- | --- |
| 找文件、读改文件、整理归档、批量读配置 | Codex 的文件工具、终端或应用接口 | 对照文件内容、目标路径、命令响应 |
| 读取网页、表单输入、提交和读取结果 | 宿主隔离浏览器或 agent-browser | 限定会话，核对 DOM 和结果状态 |
| 看窗口、点按钮、填原生表单、勾选和保存 | Codex Computer Use、agent-desktop 或 Cua Driver | 新鲜窗口引用、后台动作、应用回读和保存结果 |
| 画布、复杂控件和合法授权的远程图形控制台 | 可用的桌面视觉操作；能用 SSH 时直接用 SSH | 确认目标窗口和提示符，核对实际响应 |
| 换机、工具断线和未知投递状态 | 只读环境诊断、版本预检、一次验证后的回退 | 已安装、已连接、已授权、功能通过分别报告 |

## 要安装什么

基础安装只需要 **Codex + Python**。已有宿主浏览器、内置 Computer Use 或第三方工具时优先复用。

- **网页**可选 [agent-browser](https://github.com/vercel-labs/agent-browser)。首次还需要一个它支持的浏览器；没有时，用返回的完整路径运行 `agent-browser install`，下载 Chrome for Testing。
- **原生桌面**可选 [agent-desktop](https://github.com/vercel-labs/agent-desktop)。macOS 上按官方指引确认辅助功能权限，按需确认录屏权限。
- **额外的后台桌面通道**可选 [Cua Driver](https://github.com/trycua/cua/releases/tag/cua-driver-rs-v0.55.0)。Mac 和 Windows 可用同一套助手选择对应官方资源。Mac 按系统提示批准权限；Windows 使用已登录的交互桌面，再用本机生成的 MCP 片段接入并验收。

```sh
python3 ~/.agents/skills/jason-skill/scripts/doctor.py
python3 ~/.agents/skills/jason-skill/scripts/setup_all.py
# 需要网页和原生桌面 CLI 时，从官方 Release 下载并校验
python3 ~/.agents/skills/jason-skill/scripts/setup_all.py --apply
# 如需补浏览器运行时和对应平台的可选 Cua 通道，一起配置
python3 ~/.agents/skills/jason-skill/scripts/setup_all.py --apply --browser-runtime --include-cua
```

依赖助手复用 PATH 或已安装的版本，下载只写入用户专用版本目录。可用 `--tool agent-browser` 或 `--tool agent-desktop` 单独配置，也可用返回的完整命令路径调用。公开版下载固定为 agent-browser 0.43.0 与 agent-desktop 1.3.1。原始对比为 agent-desktop 1.2.0；1.3.1 含上游依赖修复，性能需另测。通过 `--pinned` 可在专用目录引入公开版锁定版本。首次运行在接收者电脑上验证。更多细节见[换机安装](skills/jason-skill/references/portable-install.md)。两端按[同一张验收表](benchmarks/parity/README.md)验证文件、网页、应用操作和保存。

## 脚本清单

| 文件 | 做什么 |
| --- | --- |
| [build_bundle.py](tools/build_bundle.py) | 打包 Skill、安装源码和文件哈希，生成可直接转发的单文件及 SHA-256 |
| [install_bundle.py](tools/install_bundle.py) | 离线检查文件清单与哈希，安装和重复安装，更新备份及失败回滚 |
| [doctor.py](skills/jason-skill/scripts/doctor.py) | 只读识别系统、CPU、Python 和工具存在性，提示进一步验证 |
| [setup_all.py](skills/jason-skill/scripts/setup_all.py) | 一个入口预览或配置两个 CLI，以及按需选装浏览器运行时和 Cua |
| [setup_tools.py](skills/jason-skill/scripts/setup_tools.py) | 预览或按需下载安装官方浏览器和桌面 CLI，校验资产 SHA-256，检查版本，保留已安装工具 |
| [setup_windows.py](skills/jason-skill/scripts/setup_windows.py) | 校验并选装 Windows 官方 Cua 二进制，生成当前电脑的 MCP 接入片段 |
| [setup_macos.py](skills/jason-skill/scripts/setup_macos.py) | 预览或安装可选的签名 Cua App，校验下载、签名及系统评估，返回本机 MCP 接入片段 |
| [ControlFixture.swift](benchmarks/ControlFixture.swift) | 自建原生窗口，测试点击、输入、勾选和应用回读 |

## 实测到哪里

历史本机实测记录覆盖本地表单、桌面操作和文件任务。Intel Sonoma 14.8.9 上，**本机修补版** Cua 0.55.0 在当前 Codex 会话里后台通过点击、输入、勾选、保存和文件校验。官方原版 0.55.0 的 Sonoma 后台问题要另行验收，优先选当前机器验证过的通道。这个仓库不分发本机补丁二进制或签名授权。本次已在本机模拟两端的依赖选择，尚未在 Windows 交互桌面跑完 GUI 验收。Windows ARM64 可使用本机浏览器接口；Windows 11 上也可试用固定的 x64 agent-browser 仿真包，脚本启动检查通过后再进行网页验收。Windows 10 ARM 使用现有宿主浏览器。

运行 `python3 -m unittest discover -s tests -v` 测试安装包和依赖选择。兼容性记录见 [benchmark.md](skills/jason-skill/references/benchmark.md)。

安装包不携带个人账号、Cookie、远程服务器配置、私钥或第三方二进制。MIT 许可适用于 Jason Skill 自身源码。

安全与隐私审查范围见 [SECURITY.md](SECURITY.md)。
