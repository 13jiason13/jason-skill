import SwiftUI
import AppKit
@main struct SpeedTrial:App {
    var body:some Scene {WindowGroup("后台控制速度测试") {TrialView().frame(width:500,height:330)}}
}
struct TrialView:View {
    @State private var count=0
    @State private var name=""
    @State private var enabled=false
    @State private var saved="未保存"
    @State private var revision=0
    var body:some View {
        VStack(alignment:.leading,spacing:12) {
            Text("后台控制对比测试，完成后自动关闭").font(.headline)
            HStack {TextField("测试文字",text:$name).accessibilityIdentifier("trial-name").id(revision);Toggle("启用规则",isOn:$enabled).toggleStyle(.checkbox)}
            Text("文字回读：\(name)")
            Text("启用状态：\(enabled ? "开" : "关")")
            Text("计数：\(count)")
            HStack {
                Button("增加"){count+=1}
                Button("保存测试"){saved="\(name)|\(enabled ? "开" : "关")"}
                Button("重置表单"){name="";enabled=false;saved="未保存";revision+=1}
            }
            Text("保存结果：\(saved)").accessibilityIdentifier("trial-saved")
        }.padding(24)
    }
}
