# Mac 与 Windows 共用验收

使用合成数据和任务专用窗口。先记录系统、工具版本和架构。不要以安装成功或命令返回成功替代以下结果。

| 项目 | 相同的输入与验收 |
| --- | --- |
| 本地文件 | 在空测试目录创建 `parity.txt`，写入 `Jason parity`，移动到新建的 `done` 目录。确认原路径消失，目标内容一致。 |
| 网页 | 在隔离浏览器会话打开上一级的 `browser-fixture.html`。填写 `Jason parity`、勾选 Enable test、点 Save locally，验证页面输出 `Jason parity \| enabled`。 |
| 原生桌面 | 打开下面的自建窗口。通过新鲜控件引用输入 `Jason parity`，点 Add one 一次，勾选 Enable test，点 Save test。读回窗口，确认保存；再用 `check_result.py` 检查 JSON。 |
| 速度与回退 | 分别记录冷启动和已启动的执行耗时，每条路线至少三轮。记录前台是否改变、失败重试、读回与保存。比较前先确保同样完成了验收。 |

Windows PowerShell 在本目录执行。需要已登录的本机桌面，结果路径必须未占用。

```powershell
$result = Join-Path $env:TEMP ("jason-parity-" + [guid]::NewGuid().ToString("N") + ".json")
Write-Output $result
powershell -NoProfile -STA -File .\WindowsForm.ps1 -ResultFile $result
py -3 .\check_result.py $result
```

Mac 需要 Xcode Command Line Tools。在本目录用相同结果字段验收。

```sh
probe_dir="$(mktemp -d)"
xcrun swiftc -parse-as-library MacForm.swift -o "$probe_dir/JasonParityTest"
"$probe_dir/JasonParityTest" "$probe_dir/result.json"
python3 check_result.py "$probe_dir/result.json"
```

各路线可以操作同一个自建数据与窗口，但目标应用对后台输入的支持随系统、窗口状态和权限变化。验证失败时记录软件、路线和报错，按当前授权选择已接入工具重试。
