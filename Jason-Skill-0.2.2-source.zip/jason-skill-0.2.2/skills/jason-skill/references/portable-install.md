# 换机安装与验收

接收者将单文件作为微信「文件」保存，拖进有本机终端/文件权限的 Codex，发送「安装这个 Skill，并配置需要的工具」。附件只是一份可审查安装包，不自动执行，也不携带发布者的账号或权限。

## 安装顺序

1. 按单文件内的安装器安装 Skill；已有同名版本先检查再更新，保留备份，不同时安装两份。
2. 运行 `python3 <安装目录>/scripts/doctor.py`。区分 Intel、Apple Silicon（包括 Rosetta）、macOS 版本、命令存在性和宿主实际暴露的工具。
3. 复用宿主已连接的隔离浏览器或 Computer Use。要补浏览器或桌面 CLI 时，先运行 `scripts/setup_all.py` 预览；按接收者要求用 `--apply` 安装缺项。需要安装 Chrome for Testing 可加 `--browser-runtime`，需要 Cua 可加 `--include-cua`。下载来自官方 Release，校验固定 SHA-256 和程序版本。使用输出的绝对路径调用；浏览器运行时如缺失，可按官方指引安装 Chrome for Testing。
4. macOS 的可选 Cua 路线：不为安装 Skill 重复下载驱动。配置依赖已获授权但内置能力缺失时，可运行 `scripts/setup_macos.py --plan`，审查后运行 `--apply` 安装官方签名 Cua 应用。标准库安装器支持 Python 3.8+，不会捆绑第三方二进制。
5. 依赖脚本仅安装一个 App，验证官方校验值、Apple 签名、开发者 Team ID 和系统评估；不覆盖已有 App。遇到阻止、签名异常或超时立即停止，不关闭 Gatekeeper/SIP、不改 TCC 数据库、不去掉隔离标记。
6. 用返回的 `permission_command` 打开官方授权向导，用户在原生系统界面授予辅助功能/录屏权限。管理员密码或 Touch ID 由用户完成。用户正在使用的电脑不能由安装器静默授权。
7. 用返回的 MCP 配置片段，通过接收者宿主支持的设置方式接入；片段在接收者机器生成，不复制发布者路径。保留其他 MCP 项，默认用签名 App 的 `mcp` 代理方式，避免把本机测试用的 `mcp --direct` 当作通用安装方式。需重新加载连接时如实提示。
8. 读回工具版本匹配指南，在一个自建测试窗口验证读取 → 点击计数改变 → 输入后的应用模型改变 → 保存后内容一致。网页、菜单、跨应用是独立能力，分别验收；没有测试就标记「未验证」。

## 能力状态与回退

分别报告：Skill 已安装；依赖已安装；工具已连接；权限已授予；当前场景已验收。这五个状态不能合并成「全部可用」。

- CLI/文件任务：使用 Codex 已有的终端和文件工具。
- 原生界面：选择当前机器上已验证的官方 Computer Use、Cua 或 agent-desktop。Cua 并非必需的唯一驱动；官方 Computer Use 同样是有效路线。
- 网页：已有隔离浏览器工具优先；需要 agent-browser 时按其官方安装说明配置，先验证一个本地表单。没有浏览器依赖时不声称该项已可用。
- 发生断线：先核实动作是否已经发生，避免重复提交。停止该写入路线，保存无私密内容的失败摘要；检查版本、系统和签名后最多进行一次干净重连并验收，仍失败则采用独立可用路线。

## 跨平台兼容性证据

Intel macOS 13.2.1 上，Cua 0.55.0 的简单后台控件曾验收通过。Intel Sonoma 14.8.9 上官方 Computer Use 读、点、输入和保存已验收。官方 Cua 0.55.0 的直接 MCP 后台写入曾崩溃；同机的本地兼容性修补版本后台通过了点击、输入、勾选、保存和文件内容核验。公开包保留官方签名 App 路线；新机器、原版驱动和像素写入仍须独立验收。不可把这份记录推广成所有 Sonoma 或所有 Mac 的结论。

可移植的是流程、安装代码、依赖检查和验收标准。芯片、系统、TCC、宿主工具和目标应用均会改变可用通道与速度，无法承诺「任何 Mac、任何应用、完全相同速度」。兼容性失败时优先保留用户工作并回退，而非继续点击或擅自升级系统。

## 官方依赖来源

- Cua：https://github.com/trycua/cua
- agent-desktop：https://github.com/vercel-labs/agent-desktop
- agent-browser：https://github.com/vercel-labs/agent-browser
- 官方 Computer Use：https://learn.chatgpt.com/docs/computer-use

本项目只分发自己的 MIT 源码；第三方工具从各自官方来源独立安装，受各自许可与隐私政策约束。用户不需要把自己的 Cookie、密码、SSH 密钥、API 密钥或整份 MCP 配置发给分发者。

应用进入独立 Cua daemon 时，环境变量是否继承应在接收者环境核验；可按官方文档从 Cua 自身的设置关闭遥测。


## Windows

在 Windows 上用 `py -3` 或可用的 Python 3 运行同一入口。原生桌面优先复用可调用的内置 Computer Use 或 agent-desktop；缺项时允许助手安装 Windows x64 或 ARM64 版。浏览器使用隔离会话；Windows 11 ARM 可尝试经过系统仿真的 x64 agent-browser，先验收运行时与表单。Windows 10 ARM 使用现有宿主浏览器。Cua 由 `--include-cua` 选装，在已登录的交互桌面验证，按系统要求处理提示；遇到 Defender 或组织策略阻止就回退，保留系统保护。勿假定远程服务会话或高权限窗口可以用后台输入。验收同时核对输入、点击、勾选、保存和实际文件内容。
