# Portable setup

1. Install the skill from its reviewed single-file bundle. Inspect an existing same-name installation before updating it. Preserve the backup and use the host's established skill directory.
2. Run `python3 <skill-directory>/scripts/doctor.py`. This reads platform, CPU, Python, and dependency availability.
3. Reuse connected host tools. To configure missing tools, preview `scripts/setup_all.py`, then use `--apply` within the user's setup request. `--pinned` installs the pinned distribution versions in separate user directories.
4. Add `--browser-runtime` if Chrome for Testing is needed. Add `--include-cua` for optional Cua. Use the full executable paths returned in the report.
5. On macOS, the optional Cua helper verifies the official archive, Apple signature, developer team, and Gatekeeper assessment. Follow the native system permission flow for Accessibility and Screen Recording.
6. On Windows, use `py -3` where needed. Operate from the signed-in interactive desktop. Follow system protection and organizational policy. Use the native x64 or ARM64 desktop tool; Windows 11 ARM can try the x64 browser under emulation, with a separate runtime/page test.
7. Connect the returned MCP fragment through the host's supported configuration path. It is generated for the recipient's machine. Reload the connection if required.
8. Use synthetic data to test file organization, a local browser form, native click/input/checkbox/save, and persisted-output readback. Report installation, connection, permission, and acceptance as separate states.

When a driver disconnects after a write, inspect the application and saved result first. Reconnect once when justified, verify the state, and use an independently available route if the failure persists.

## Compatibility evidence

Simple background controls passed on one Intel macOS 13.2.1 host with Cua 0.55.0. On one Intel macOS 14.8.9 host, built-in Computer Use passed preliminary read, click, input, and save checks. An official Cua direct-mode background-input route crashed there; a local source compatibility patch subsequently passed a synthetic native form and saved-file check.

The public package provides the patch source separately. It has no publisher code-signing grant or private host configuration. New machines, unpatched releases, pixel input, other applications, Windows GUI, and cross-machine speed require their own acceptance tests.

## Privacy

Skill installation can run offline. Explicit dependency installation contacts official release sources and, if requested, the upstream browser-runtime installer. The generated Cua MCP child environment opts out of Cua telemetry. A separately running daemon may have its own environment; verify its effective settings through upstream documentation.

Project source is MIT licensed. Third-party binaries retain their own upstream licenses. Recipients keep their own accounts, credentials, browser profiles, SSH keys, and system grants.
