# 工具接入与回退

## Cua Driver

在宿主实际暴露的 MCP 工具中确认可调用性。先调用 `check_permissions`，通过 `get_guide` 加载 overview 和对应平台指导。此包测试版本为 0.55.0；其他版本以自身指南为准。

用 `list_windows` 定位 pid/window_id，再窄范围 `get_window_state`。已知动作采用 `run_steps` 并请求一次观察，避免紧跟重复读取。适用时使用后台投递，关闭自动前台回退。快照或窗口改变后刷新元素 token。

本机 SwiftUI 表单中 `set_value` 曾只改变可访问性字段属性，没有改变应用模型；`type_text` 通过了模型回读和保存验收。这个发现仅适用于已测控件，填写其他应用时仍要验收。

MCP 配置命令和安装路径应从接收者当前环境获得，不复制分发者的路径、全局配置或系统权限数据库。驱动支持不等于每个应用支持后台输入。

官方来源：https://github.com/trycua/cua

## agent-desktop

首次使用运行 `agent-desktop status`、`agent-desktop skills get desktop`、`agent-desktop skills get platform`。命令不在 PATH 时先定位用户已安装的位置，或使用 `scripts/setup_tools.py` 输出的专用命令路径。

优先 find 或窄范围 snapshot。只使用新鲜、限定窗口的引用；动作后核实实际结果。语义操作没有生效时，先读回现场；不自动升级为抢占前台的物理输入。

官方来源：https://github.com/vercel-labs/agent-desktop

## 后台浏览器

已有浏览器工具能完成任务时复用；选择隔离会话处理可支持的网页任务。采用任务专属会话，避免读取用户其他标签或复制 Cookie。需要已有登录态时使用宿主正式支持的用户浏览器连接。

agent-browser 的本地事件表单已验证；本机一次 YouTube 有界面启动超时。不能据此声称任何真实网站都能更快完成。

官方来源：https://github.com/vercel-labs/agent-browser

## 内置 Computer Use

先检查当前宿主设置、权限和实际可调用工具。Codex 桌面内置能力与单独调用 OpenAI API 是两种接入方式；内置功能不应被误写成必须另配 API 密钥。

需要像素交互时，先观察当前目标画面，确认窗口与坐标映射，动作后验收。前台输入会影响共享鼠标键盘时提前告知。遇到画布等没有完整可访问性控件的内容，视觉路线可能更适合。

官方说明：https://learn.chatgpt.com/docs/computer-use

API 接口说明：https://developers.openai.com/api/docs/guides/tools-computer-use

## 图形远程控制台

区分 login、Password 和 shell 提示符。发送长文本前用短的无副作用输入验证传输；换行或特殊字符失真时停止批量输入。Connected 只证明控制通道建立，不证明服务器网络和服务正常。恢复 SSH 后，服务诊断优先使用 SSH。
