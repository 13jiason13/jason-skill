"""Portable, read-only environment report. No credentials or application data."""
import ctypes
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path


def mac_arch(machine=None, arm_capable=None):
    machine = machine or platform.machine()
    if arm_capable is None and platform.system() == 'Darwin':
        try:
            arm_capable = subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.optional.arm64'], stderr=subprocess.DEVNULL, timeout=3).decode().strip() == '1'
        except (OSError, subprocess.SubprocessError):
            arm_capable = machine == 'arm64'
    return 'arm64' if machine == 'arm64' or arm_capable else 'x86_64'


def windows_arch():
    # Use the native machine even if Python itself is running under Windows emulation.
    try:
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        from ctypes import wintypes
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        kernel.IsWow64Process2.argtypes = [
            wintypes.HANDLE, ctypes.POINTER(ctypes.c_ushort), ctypes.POINTER(ctypes.c_ushort)
        ]
        kernel.IsWow64Process2.restype = wintypes.BOOL
        process = ctypes.c_ushort()
        native = ctypes.c_ushort()
        if kernel.IsWow64Process2(kernel.GetCurrentProcess(), ctypes.byref(process), ctypes.byref(native)):
            return {0xAA64: "arm64", 0x8664: "x86_64", 0x014C: "x86"}.get(
                native.value, platform.machine().lower())
    except (AttributeError, OSError):
        pass
    machine = platform.machine().lower()
    return {"amd64": "x86_64", "aarch64": "arm64"}.get(machine, machine)


def windows_build():
    try:
        info = sys.getwindowsversion()
        return getattr(info, "platform_version", (0, 0, info.build))[2]
    except (AttributeError, IndexError):
        return 0


def inspect():
    system = platform.system()
    version = platform.mac_ver()[0] if system == 'Darwin' else platform.release()
    warnings = []
    if system == 'Darwin' and version.startswith('14.'):
        warnings.append('Cua Driver 0.55.0 background-input crash was observed on one Intel Sonoma host. Prefer callable official Computer Use for writes until this host passes a synthetic write/save test. Reinstall alone is not proof of repair.')
    paths = (Path('/Applications/CuaDriver.app'), Path.home()/'Applications/CuaDriver.app')
    return {
        'platform': system, 'os_version': version, 'architecture': {
            'Darwin': mac_arch, 'Windows': windows_arch
        }.get(system, platform.machine)(),
        'windows_build': windows_build() if system == 'Windows' else None,
        'python_supported': sys.version_info >= (3, 8),
        'commands': {name: bool(shutil.which(name)) for name in ('python3', 'agent-desktop', 'agent-browser', 'cua-driver')},
        'managed_tools': {
            name: any(
                p.is_file() and not p.is_symlink()
                for p in (Path.home()/'.local/share/jason-skill/tools'/name).glob(
                    '*/' + name + ('.exe' if system == 'Windows' else '')
                )
            ) for name in ('agent-desktop', 'agent-browser')
        },
        'cua_app_installed': any(p.is_dir() for p in paths),
        'builtin_computer_use': 'Host must check currently callable tools and run an owned-window test; no separate API key is implied.',
        'gui_verified': False, 'warnings': warnings,
        'next_steps': ['Inspect callable host tools first.', 'Use setup_macos.py --plan to inspect the optional signed Cua installation.', 'User grants macOS privacy permissions in System Settings.', 'Verify read, click, input model and saved result on synthetic data before claiming GUI readiness.'],
        'note': 'No username, home path, account, file listing, browser state, network state or telemetry is collected. Presence is not runtime success.'
    }

if __name__ == '__main__':
    print(json.dumps(inspect(), ensure_ascii=False, indent=2))
