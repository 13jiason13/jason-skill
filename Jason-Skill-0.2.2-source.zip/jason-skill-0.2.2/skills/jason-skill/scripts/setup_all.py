"""One entry to preview or configure Jason Skill's third-party routes."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import zipfile

import setup_macos
import setup_tools
import setup_windows


CLI_READY = {"found-not-GUI-verified", "installed-binary-version-verified"}


def run_setup(args):
    system, arch = key = setup_tools.platform_key()
    cli = setup_tools.resolve_tools(args.tool_root.expanduser().absolute(), key,
                                    list(setup_tools.VERSIONS), args.pinned, args.apply)
    result = {"mode": "applied" if args.apply else "preview", "toolchain": cli,
              "browser_runtime": {"status": "reuse-or-configure-if-needed"},
              "cua": {"status": "optional-not-requested"}, "gui_verified": False}
    browser = next(item for item in cli if item["tool"] == "agent-browser")
    if args.browser_runtime:
        if not args.apply:
            result["browser_runtime"] = {"status": "planned", "source": "agent-browser install"}
        elif browser["status"] in CLI_READY:
            try:
                subprocess.run([browser["command"], "install"], capture_output=True,
                               timeout=420, check=True)
                result["browser_runtime"] = {"status": "installed-needs-browser-test"}
            except (OSError, subprocess.SubprocessError) as error:
                result["browser_runtime"] = {"status": "failed", "error": str(error)}
        else:
            result["browser_runtime"] = {"status": "failed", "error": "agent-browser unavailable"}
    if args.include_cua:
        try:
            result["cua"] = configure_cua(args, system, arch)
        except (OSError, ValueError, subprocess.SubprocessError, tarfile.TarError, zipfile.BadZipFile) as error:
            result["cua"] = {"status": "failed", "error": str(error)}
    return result


def configure_cua(args, system, arch):
    if system == "Windows":
        target = args.cua_target or args.tool_root / "cua-driver" / setup_windows.VERSION
        item = setup_windows.plan(arch, target.expanduser().absolute(), args.pinned)
        if args.apply and item["status"] == "planned":
            return setup_windows.install(item)
        return item
    if system != "Darwin":
        return {"status": "use-host-or-upstream", "reason": "This helper supports macOS and Windows"}
    target = (args.cua_target or Path.home() / "Applications/CuaDriver.app").expanduser().absolute()
    if target.is_symlink():
        return {"status": "inspect-existing", "target": str(target)}
    if target.is_dir():
        return {"status": "existing-needs-runtime-test", "target": str(target)}
    if not args.apply:
        return {"status": "planned", "version": setup_macos.VERSION, "target": str(target)}
    return setup_macos.install(arch, target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--browser-runtime", action="store_true", help="Run upstream Chrome for Testing setup")
    parser.add_argument("--include-cua", action="store_true", help="Optionally set up official Cua on macOS or Windows")
    parser.add_argument("--pinned", action="store_true")
    parser.add_argument("--tool-root", type=Path, default=setup_tools.ROOT)
    parser.add_argument("--cua-target", type=Path)
    args = parser.parse_args()
    result = run_setup(args)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    statuses = [*result["toolchain"], result["browser_runtime"], result["cua"]]
    return 1 if any(item["status"] == "failed" for item in statuses) else 0


if __name__ == "__main__":
    sys.exit(main())
