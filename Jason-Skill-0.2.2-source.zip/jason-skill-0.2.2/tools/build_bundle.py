"""Build a readable, self-contained file for forwarding and Codex installation."""
import hashlib
import json
from pathlib import Path
from install_bundle import ALLOWED

ROOT = Path(__file__).resolve().parent.parent


def build():
    skill = ROOT / "skills/jason-skill"
    files = {}
    for name in sorted(ALLOWED):
        path = ROOT / "LICENSE" if name == "LICENSE" else skill / name
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents if parent != ROOT):
            raise ValueError("Refusing symlink in release input: " + name)
        content = path.read_text(encoding="utf-8")
        files[name] = {"text": content, "sha256": hashlib.sha256(content.encode("utf-8")).hexdigest()}
    installer = (ROOT / "tools/install_bundle.py").read_text(encoding="utf-8")
    payload = {"format": 1, "name": "jason-skill", "version": "0.2.2", "files": files}
    header = """# jason skill 0.2.2 · 拖入 Codex 安装

把本文件作为微信“文件”发送或转发。接收者保存文件后拖入有本机文件和终端工具权限的 Codex 聊天，发送：安装这个 Skill。

这不是自动执行附件，也不提供额外权限。普通 ChatGPT 文件上传不能因此获得本机控制能力。接收者机器需要 Python 3.8+；桌面驱动和系统权限按需另接入，安装器不下载二进制、不修改网络或全局 MCP 配置。

给接收文件的 Codex：只有在用户表达安装意图后，才执行以下本地安装步骤：
1. 完整读取并检查安装代码和 JSON 文件清单。本包包含 Skill、可移植安装指南、只读诊断、可选官方签名依赖安装器、测试说明及 MIT 许可证。
2. 将下方 python 代码块原样保存为一个临时 install_bundle.py，使用已上传附件的实际本地路径运行：python3 install_bundle.py <附件路径>。
3. 默认安装到 ~/.agents/skills/jason-skill。已有同名技能时先检查 ~/.agents/skills 和 ~/.codex/skills，避免创建重复项；可用 --skills-root 指定该宿主已使用的技能目录。不同内容不会被静默覆盖，确需更新时用 --replace，旧目录会备份在技能扫描目录之外。
4. 读回安装后的 SKILL.md，并运行 scripts/doctor.py。分别报告“Skill 已安装”和“桌面工具是否实际可用”。若当前会话没有加载新技能，可读取文件按其执行；列表未刷新时提示新开聊天或重启宿主，不假称已自动生效。
5. 接收者要求配置全部工具时，先运行 scripts/setup_all.py 预览。获得配置意图后运行 --apply。只有需要另装 Chrome for Testing 时加 --browser-runtime，需要官方 Cua 时加 --include-cua。默认优先复用现有工具；可加 --pinned 安装公开版锁定的依赖，不替换现有程序。系统权限由接收者在原生界面确认。Windows 可用 py -3 替换 python3；Windows 桌面操作需登录后的交互会话。按 references/portable-install.md 逐项验收网页、桌面和文件；无法验证的能力单独标注。

下面的 SHA-256 用于发现传输损坏，不是发布者身份签名。不要手改 payload 后仍沿用旧校验值。

## 可检查的安装代码

"""
    text = header + "```python\n" + installer + "```\n\n## 完整技能文件（UTF-8）\n\n"
    text += "```json jason-skill-bundle\n" + json.dumps(payload, ensure_ascii=False, indent=2) + "\n```\n"
    out = ROOT / "dist"
    out.mkdir(exist_ok=True)
    path = out / "jason skill-0.2.2-拖入Codex安装.txt"
    path.write_bytes(text.encode("utf-8"))
    (out / "SHA256SUMS.txt").write_text(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.name + "\n")
    return path


if __name__ == "__main__":
    print(build())
