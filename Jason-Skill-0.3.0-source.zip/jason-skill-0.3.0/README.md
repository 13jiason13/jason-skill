# Jason Skill

## Download the latest complete pack — v0.3.0

**Choose a full platform pack from [the latest release](https://github.com/13jiason13/jason-skill/releases/tag/v0.3.0).** It includes the actual tools and runtime, not just instructions or setup scripts. The source-code ZIP and single-file skill installer are advanced alternatives; they are not the complete offline tool pack.

| Your computer | Complete download |
| --- | --- |
| Mac with Intel processor | [macOS x64](https://github.com/13jiason13/jason-skill/releases/download/v0.3.0/Jason-Skill-0.3.0-macos-x64.tar.gz) |
| Mac with Apple Silicon | [macOS ARM64](https://github.com/13jiason13/jason-skill/releases/download/v0.3.0/Jason-Skill-0.3.0-macos-arm64.tar.gz) |
| Windows x64 | [Windows x64](https://github.com/13jiason13/jason-skill/releases/download/v0.3.0/Jason-Skill-0.3.0-windows-x64.zip) |
| Windows 11 ARM | [Windows ARM64 preview](https://github.com/13jiason13/jason-skill/releases/download/v0.3.0/Jason-Skill-0.3.0-windows-arm64.zip) — browser uses x64 OS emulation |

Verify the archive against the release's `SHA256SUMS.txt`, extract the entire archive, and run **Install.command** on Mac or **Install.cmd** on Windows. The installer copies the runtime and tools into a stable user directory, installs the skill, and runs real local acceptance checks. No tool download or separate Python installation is needed for a complete pack. Keep normal operating-system trust and organization policies in place.

Use an AI host with local file and terminal access, then invoke **`$jason-skill`**. Complete local Accessibility/Screen Recording grants and your own website sign-ins when requested. A host refresh or new chat may be needed after skill installation.

## What is actually included

- CPython 3.12.16 standalone runtime.
- Open-source Chromium 141.0.7390.37 / Playwright build 1194.
- agent-browser 0.43.0 and agent-desktop 1.3.1 native binaries.
- Unmodified official Cua Driver 0.55.0 as an optional additional route; macOS includes the signed upstream app.
- Existing file, text, record, browser and desktop task implementations, sample jobs, environment helpers and native acceptance material.
- Integrity manifests, upstream license copies, source provenance and the optional Cua Sonoma patch source.

AI models, hosted Computer Use, subscriptions, accounts, credentials, browser profiles and system permissions are supplied by the recipient; they are not redistributed. New machines and target applications can behave differently. The installer reports an actual readiness result instead of equating binary presence with working automation.

## Existing functions

| Task | Installed implementation |
| --- | --- |
| Organize and rename files | Extension-based groups, collision/link checks, verified content and metadata, rollback and undo manifest |
| Revise text reports | Exact-count replacements, optional append, preserved input and line endings, new output |
| Process CSV records | Filter, numeric thresholds, selection/output sorting, bulk updates, immutable IDs, exact decimal summary |
| Run browser workflows | Isolated session, fresh role/name targets, input/select/check/click, visible result assertions |
| Run desktop workflows | Current app/window targets, agent-desktop or optional Cua, input/check/click/save and actual-result assertions |
| Install and verify | Offline runtime/tool configuration plus local file, browser and owned-window acceptance |

The first three are immediately executable bundled functions, not prompts asking the AI to rewrite the same code. Browser and desktop recipes are executable too, but target labels, permissions and sign-ins must match the task. See [automation usage](skills/jason-skill/references/automation.md) and the installed `examples/`.

```sh
# A complete pack supplies Python through this launcher.
./Jason.command capabilities
./Jason.command run reviewed-job.json
./Jason.command run reviewed-job.json --apply
```

On Windows use `Jason.cmd`. File jobs preview by default; apply only a job whose targets and effects match your request. The host's existing action-confirmation rules still apply.

## Verified scope

- 35 local automated tests passed, including installer integrity/rollback and task safety regressions.
- An independent forward test exercised real file/text/record jobs, collisions, rollback, metadata, symlink refusal and CSV output ordering.
- On one Intel Mac running macOS 14.8.9, the complete pack's own Python, Chromium and pinned agent-desktop passed a real offline install plus file processing, browser form submission, native text/checkbox/click/save and saved-file readback. No system browser or preinstalled Python was needed by that pack.
- ARM64 binaries are packaged from verified upstream assets; Apple Silicon and Windows GUI remain recipient-side acceptance requirements unless a separately recorded real run is provided. Windows 11 ARM's browser uses x64 emulation.
- The optional official Cua 0.55.0 route has a known Intel Sonoma background-input issue. Its source-only compatibility patch is included; the main desktop acceptance uses agent-desktop. A present Cua executable is not reported as an accepted Cua route.

The earlier comparison of 30 same-window GUI runs found advantages in different tasks for each interface, not a universal speed multiplier. This package makes no claim that every computer, application or AI host will reproduce one machine's speed.

## Source and licenses

[MIT license](LICENSE) applies to Jason Skill code. Bundled third-party components keep their own licenses and notices: [third-party notices](THIRD-PARTY-NOTICES.md). The [source archive](https://github.com/13jiason13/jason-skill/releases/download/v0.3.0/Jason-Skill-0.3.0-source.zip) includes task code, tests, source patch and reproducible pack builders. Vendor URLs and exact hashes are recorded in `tools/vendor-lock.json`. Upstream source/build recipes remain available from the linked version tags.

For a source-only skill install, Python 3.8+ is required. `tools/build_bundle.py` produces the readable TXT installer; `tools/install_bundle.py` validates and installs its explicit file manifest. `scripts/bootstrap.py` handles on-demand configuration and functional checks. Complete platform packs avoid that dependency-download step.

[Security and privacy](SECURITY.md) · [Release notes](RELEASE-NOTES.md)
