# Jason Skill v0.3.0 — Complete Tool Packs Preview

This release adds complete per-platform packs with actual runtimes and binaries, reusable task implementations, and functional installation acceptance.

## Added

- Bundled Python, Chromium, agent-browser, agent-desktop and optional official Cua.
- Mac Intel, Mac Apple Silicon, Windows x64 and Windows 11 ARM preview packs.
- File organization/undo, text revision, CSV processing and reviewed browser/desktop recipe runners.
- Stable local installation paths and runtime command discovery without global PATH or MCP edits.
- Owned native-window tests with real persisted-output verification; explicit ready/not-ready reports.
- License notices, vendor locks and whole-pack integrity manifests.

## Validation

35 local tests pass. Independent file/text/CSV acceptance and a complete Intel Mac offline installation passed. Other machines and GUI targets need their own acceptance. Windows ARM browser support uses Windows 11 x64 emulation. An upstream Intel Sonoma Cua issue is documented; main desktop acceptance uses agent-desktop, and optional Cua needs separate acceptance.

This preview does not redistribute hosted AI access, system permissions, accounts or browser state and does not promise identical cross-machine speed. The v0.2.2 release remains in the release history.
