# Security and privacy

Complete packs contain reviewed project code and pinned upstream open-source runtime/tool artifacts. They contain no publisher credentials, cookies, browser profiles, home-directory configuration, SSH/VPS information, private files, accounts or model entitlements.

Verify the release SHA-256 before extraction and execution. `PACK.json` verifies files after extraction, including safe relative symlinks; it detects corruption but does not independently authenticate the publisher. Upstream signed macOS Cua content is preserved unchanged. No installer disables Gatekeeper, modifies Windows execution policy, grants system permissions, changes the active network, or writes global MCP/PATH settings.

Installation writes a stable user tool directory, the user skill directory, backups of replaced skill files and a local runtime command-path configuration. It runs synthetic local acceptance tasks. Full packs do not need tool downloads; browser actions can access only the sites/tasks requested by their caller. Native desktop acceptance briefly brings its own harmless test window to the foreground. Permissions and sign-ins remain on the recipient's machine.

Jobs are data, not authorization. Inspect targets, destinations and effects before --apply, and retain host confirmation boundaries for consequential actions. A downloaded recipe cannot authorize itself. Generic recipe runners contain no arbitrary shell/eval action or browser-state export. Ambiguous targets stop, uncertain writes are not blindly retried, and final application state must be asserted.

File operations refuse collisions and symlink target groups, verify content, preserve original text inputs, and provide rollback/undo checks. Back up important user data independently; preview and synthetic acceptance do not replace application-specific validation.

Keep reports containing real user paths, form contents, screenshots or secrets out of public issues. Report a sanitized reproducer. Third-party tools have their own upstream behavior and license terms; see THIRD-PARTY-NOTICES.md. Host model use, quota and built-in Computer Use are outside this package.
