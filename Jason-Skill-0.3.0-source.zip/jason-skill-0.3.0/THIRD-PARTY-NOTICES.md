# Third-party notices

Jason Skill task code is MIT licensed. Complete platform packs retain vendor archives, license files and component notices. No publisher browser profile, credential or account is included.

| Component | Source / version | License |
| --- | --- | --- |
| agent-browser | https://github.com/vercel-labs/agent-browser/tree/v0.43.0 | Apache-2.0 |
| agent-desktop | https://github.com/vercel-labs/agent-desktop/tree/v1.3.1 | Apache-2.0 |
| Cua Driver | https://github.com/trycua/cua/tree/cua-driver-rs-v0.55.0 | MIT; signed upstream macOS app remains unmodified |
| CPython runtime | Python 3.12.16 from astral-sh/python-build-standalone release 20261124 | CPython PSF license plus included dependency licenses |
| Python standalone build project | https://github.com/astral-sh/python-build-standalone/tree/20261124 | MPL-2.0 build project; runtime component licenses are retained separately |
| Chromium | 141.0.7390.37, Playwright revision 1194 | Chromium BSD-style license and bundled third-party notices |
| Playwright browser build provenance | https://github.com/microsoft/playwright/blob/v1.56.1/packages/playwright-core/browsers.json | Build tooling Apache-2.0; browser retains its own licenses |

Copies are under `licenses/` and inside the original runtime/application directories. `tools/vendor-lock.json` records vendor URLs and hashes. Python and Cua hashes are checked against upstream GitHub release digests; browser and desktop CLI hashes are pinned. Chromium archive hashes were recorded after official HTTPS download and are fixed in the release lock.

No proprietary Google Chrome build, AI model, hosted Computer Use service, subscription, or account entitlement is redistributed. The included browser is the open-source Chromium build supplied through the Playwright browser distribution.
