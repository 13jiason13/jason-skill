"""Portable task implementations. Standard library only; no shell or telemetry."""
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import queue
import re
import shutil
import subprocess
import threading
import time
from decimal import Decimal
from urllib.parse import urlparse
import uuid

GROUPS = {'.csv':'tables','.tsv':'tables','.png':'images','.jpg':'images',
          '.jpeg':'images','.webp':'images','.txt':'docs','.md':'docs','.pdf':'docs'}

def digest(path):
    value=hashlib.sha256()
    with path.open('rb') as file:
        for chunk in iter(lambda:file.read(1024*1024),b''):value.update(chunk)
    return value.hexdigest()

def local_path(value):
    path=Path(value).expanduser().absolute()
    if platform.system()=='Darwin' and len(path.parts)>1 and path.parts[1] in ('var','tmp','etc'):
        path=Path('/private')/path.relative_to('/')
    if any(p.is_symlink() for p in (path,*path.parents)):
        raise ValueError('Inspect symbolic links before selecting this path')
    return path

def filename(value):
    if (not isinstance(value,str) or not value or value in ('.','..')
        or re.search(r'[<>:"/\\|?*\x00-\x1f]',value) or value.endswith((' ','.'))
        or re.fullmatch(r'(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?',value,re.I)):
        raise ValueError('Expected a portable single filename')
    return value

def write_new(path,data):
    path=local_path(path)
    if not path.parent.is_dir():raise ValueError('Output parent does not exist')
    with path.open('xb') as file:file.write(data)

def organize(job,apply=False):
    source=local_path(job['source']);destination=local_path(job['destination'])
    if not source.is_dir():raise ValueError('Source directory does not exist')
    if destination.exists() and not destination.is_dir():raise ValueError('Destination root is not a directory')
    if source==destination or source in destination.parents:
        raise ValueError('Use an independent destination outside the source')
    renames=job.get('rename',{});groups={**GROUPS,**job.get('groups',{})}
    manifest=destination/'jason-manifest.json'
    if manifest.exists():raise FileExistsError('Destination already has a manifest')
    moves=[];targets=set()
    for src in sorted(source.iterdir()):
        if src.is_symlink():raise ValueError('Source contains a symbolic link')
        if not src.is_file():continue
        group=filename(groups.get(src.suffix.lower(),'other'))
        folder=local_path(destination/group)
        if folder.exists() and not folder.is_dir():raise ValueError('A destination group is not a directory')
        name=filename(renames.get(src.name,src.name));dst=local_path(folder/name)
        key=str(dst).casefold()
        if key in targets or dst.exists() or dst.is_symlink():raise FileExistsError('Destination collision: '+str(dst))
        targets.add(key)
        moves.append({'source':str(src),'destination':str(dst),'sha256':digest(src)})
    known={Path(item['source']).name for item in moves}
    if set(renames)-known:raise ValueError('Rename rule refers to a missing source file')
    result={'type':'files.organize','applied':False,'count':len(moves),'moves':moves}
    if not apply:return result
    completed=[]
    try:
        for item in moves:
            src=local_path(item['source']);dst=local_path(item['destination'])
            if digest(src)!=item['sha256']:raise ValueError('Source changed during planning')
            dst.parent.mkdir(parents=True,exist_ok=True)
            # Do not overwrite a newly appeared file, even on POSIX rename.
            with dst.open('xb') as output,src.open('rb') as input:
                try:shutil.copyfileobj(input,output)
                except BaseException:output.close();dst.unlink();raise
            if digest(dst)!=item['sha256']:dst.unlink();raise ValueError('Copied content differs')
            shutil.copystat(src,dst)
            src.unlink();completed.append(item)
        destination.mkdir(parents=True,exist_ok=True)
        write_new(manifest,json.dumps({'format':1,'moves':moves},indent=2).encode())
    except BaseException:
        for item in reversed(completed):
            src=Path(item['source']);dst=Path(item['destination'])
            if not src.exists() and dst.is_file() and digest(dst)==item['sha256']:
                shutil.copy2(dst,src);dst.unlink()
        raise
    return {**result,'applied':True,'manifest':str(manifest),'verified':True}

def undo_organize(job,apply=False):
    manifest=local_path(job['manifest']);data=json.loads(manifest.read_text())
    if data.get('format')!=1:raise ValueError('Unsupported manifest')
    for item in data['moves']:
        source=local_path(item['source']);destination=local_path(item['destination'])
        if source.exists() or not destination.is_file() or digest(destination)!=item['sha256']:
            raise ValueError('Undo would overwrite or restore changed data')
    if apply:
        for item in reversed(data['moves']):
            source=Path(item['source']);destination=Path(item['destination'])
            with source.open('xb') as output,destination.open('rb') as input:shutil.copyfileobj(input,output)
            if digest(source)!=item['sha256']:source.unlink();raise ValueError('Undo verification failed')
            shutil.copystat(destination,source)
            destination.unlink()
    return {'type':'files.undo','applied':apply,'restored':len(data['moves'])}

def edit_text(job,apply=False):
    source=local_path(job['source']);output=local_path(job['output'])
    if output.exists() or source==output:raise FileExistsError('Choose a new output file')
    encoding=job.get('encoding','utf-8')
    with source.open('r',encoding=encoding,newline='') as file:text=file.read()
    counts=[]
    for rule in job.get('replacements',[]):
        old=rule['old'];new=rule['new']
        if not old:raise ValueError('Empty replacement target')
        count=text.count(old)
        if count!=rule.get('expected_count',1):raise ValueError('Replacement count differs from the reviewed job')
        text=text.replace(old,new);counts.append(count)
    text+=job.get('append','')
    if apply:write_new(output,text.encode(encoding))
    return {'type':'text.edit','applied':apply,'replacement_counts':counts,
            'output':str(output),'output_sha256':hashlib.sha256(text.encode(encoding)).hexdigest()}

def update_records(job,apply=False):
    source=local_path(job['source']);output=local_path(job['output']);summary=local_path(job['summary'])
    if output==summary or any(p.exists() for p in [output,summary]):raise FileExistsError('Choose independent new outputs')
    with source.open('r',encoding='utf-8-sig',newline='') as file:
        reader=csv.DictReader(file);fields=reader.fieldnames;rows=list(reader)
    if not fields or any(None in row for row in rows):raise ValueError('Invalid CSV columns')
    if job['id'] in job.get('updates',{}):raise ValueError('Record identifiers are immutable')
    if job.get('output_mode','all') not in ['all','selected']:raise ValueError('Unknown record output mode')
    columns=set(job.get('where',{}))|set(job.get('minimum',{}))|set(job.get('updates',{}))
    for name in ('id','sum'):columns.add(job[name])
    if job.get('sort'):columns.add(job['sort']['column'])
    if not columns.issubset(fields):raise ValueError('Job refers to an absent column')
    selected=[row for row in rows if all(row[k]==str(v) for k,v in job.get('where',{}).items())
              and all(Decimal(row[k])>=Decimal(str(v)) for k,v in job.get('minimum',{}).items())]
    if job.get('sort'):
        order=job['sort'];selected.sort(key=lambda row:Decimal(row[order['column']]),reverse=order.get('descending',False))
    ids=[row[job['id']] for row in selected]
    if len(set(row[job['id']] for row in rows))!=len(rows):raise ValueError('Record IDs must be unique')
    total=sum((Decimal(row[job['sum']]) for row in selected),Decimal(0))
    for row in selected:row.update({k:str(v) for k,v in job.get('updates',{}).items()})
    result={'type':'records.update','applied':apply,'selected':ids,'count':len(ids),'total':str(total)}
    if apply:
        output_rows=selected if job.get('output_mode','all')=='selected' else rows
        if job.get('sort_output') and job.get('sort'):
            order=job['sort'];output_rows=sorted(output_rows,key=lambda row:Decimal(row[order['column']]),reverse=order.get('descending',False))
        buffer=io.StringIO(newline='');writer=csv.DictWriter(buffer,fieldnames=fields);writer.writeheader();writer.writerows(output_rows)
        write_new(output,buffer.getvalue().encode('utf-8'))
        try:write_new(summary,json.dumps(result,indent=2).encode())
        except BaseException:output.unlink();raise
    return result

def command_for(name,explicit=None):
    if explicit:
        path=local_path(explicit)
        if not path.is_file():raise FileNotFoundError('Tool command does not exist')
        return str(path)
    config=Path.home()/'.local/share/jason-skill/runtime.json'
    if config.is_file():
        settings=json.loads(config.read_text())
        configured=settings.get('cua_command') if name=='cua-driver' else settings.get('commands',{}).get(name)
        if configured and Path(configured).is_file():return configured
    found=shutil.which(name)
    if found:return found
    if name=='cua-driver':raise FileNotFoundError('Configure optional Cua or select the agent-desktop route')
    import setup_tools
    key=setup_tools.platform_key();planned=setup_tools.plan_tool(name,setup_tools.ROOT,key)
    if planned['status']=='found-not-GUI-verified':return planned['command']
    raise FileNotFoundError('Run scripts/bootstrap.py --apply to configure '+name)

def cli_json(command,args,timeout=45):
    result=subprocess.run([command,*args],capture_output=True,text=True,encoding='utf-8',timeout=timeout)
    try:data=json.loads(result.stdout)
    except ValueError:raise RuntimeError('Tool did not return JSON; inspect its version and installation')
    if result.returncode or data.get('success') is False or data.get('ok') is False:
        raise RuntimeError('Tool action failed; inspect current state before retrying: '+str(data.get('error','unknown error')))
    return data.get('data',data)

def validate_workflow(job,kind):
    steps=job.get('steps')
    if not isinstance(steps,list) or not 1<=len(steps)<=200 or steps[-1].get('action')!='expect_text':raise ValueError('End a bounded workflow with an explicit result assertion')
    actions=['fill','click','check','uncheck','expect_text']+(['select'] if kind=='browser' else [])
    for step in steps:
        if step.get('action') not in actions:raise ValueError('Unsupported workflow action')
        if step['action']=='expect_text':
            if not isinstance(step.get('text'),str) or not step['text']:raise ValueError('A result assertion must have nonempty expected text')
        else:
            if not isinstance(step.get('name'),str) or (not step['name'] and step.get('role')!='textarea'):raise ValueError('A target needs an exact name')
            if kind=='desktop' and step.get('role') not in ['button','textfield','textarea','checkbox']:raise ValueError('Unsupported desktop role')
            if kind=='browser' and not isinstance(step.get('role'),str):raise ValueError('A browser target needs a role')
            if step['action'] in ['fill','select'] and not isinstance(step.get('value'),str):raise ValueError('Text entry needs a string value')

def browser(job,apply=False,tool=None,executable_path=None):
    validate_workflow(job,'browser')
    if not job.get('steps') or job['steps'][-1]['action']!='expect_text':raise ValueError('A workflow must end with an explicit result assertion')
    if any(s.get('action') not in ['fill','click','check','uncheck','select','expect_text'] for s in job['steps']):raise ValueError('Unsupported browser action')
    if not apply:return {'type':'browser.workflow','applied':False,'steps':len(job['steps']),'url':job['url']}
    if urlparse(job['url']).scheme not in ['http','https','file']:raise ValueError('Unsupported starting URL')
    executable=command_for('agent-browser',tool)
    session=job.get('session','jason-'+uuid.uuid4().hex[:12])
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',session):raise ValueError('Invalid isolated session name')
    config=Path.home()/'.local/share/jason-skill/runtime.json'
    runtime=json.loads(config.read_text()) if config.is_file() else {}
    browser_path=executable_path or job.get('executable_path') or runtime.get('browser_executable')
    launch=['--executable-path',str(browser_path)] if browser_path else []
    def call(*args):return cli_json(executable,['--session',session,*launch,*args,'--json'])
    call('open',job['url']);count=0
    for index,step in enumerate(job['steps']):
        action=step['action']
        if action=='expect_text':
            state=call('snapshot')['snapshot']
            if step['text'] not in state:raise ValueError('Expected page result was not observed at step '+str(index))
        else:
            if action not in ['fill','click','check','uncheck','select']:raise ValueError('Unsupported browser action')
            state=call('snapshot','-i')
            matches=[key for key,value in state['refs'].items() if value.get('name')==step['name'] and value.get('role')==step['role']]
            if len(matches)!=1:raise ValueError('Page target is absent or ambiguous at step '+str(index))
            args=[action,'@'+matches[0]]
            if action in ['fill','select']:args.append(step['value'])
            call(*args)
        count+=1
    if not job['steps'] or job['steps'][-1]['action']!='expect_text':
        raise ValueError('A workflow must end with an explicit result assertion')
    return {'type':'browser.workflow','applied':True,'verified':True,'steps_completed':count,'session':session}

class CuaClient:
    def __init__(self,command):
        self.process=subprocess.Popen([command,'mcp','--direct','--no-overlay'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8',bufsize=1,env={**os.environ,'DO_NOT_TRACK':'1','CUA_TELEMETRY':'0'})
        self.messages=queue.Queue();self.counter=0
        def read():
            for line in self.process.stdout:
                try:self.messages.put(json.loads(line))
                except ValueError:pass
        threading.Thread(target=read,daemon=True).start()
        self.rpc('initialize',{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'jason-automation','version':'0.3.0'}})
        self.process.stdin.write(json.dumps({'jsonrpc':'2.0','method':'notifications/initialized'})+'\n');self.process.stdin.flush()
    def rpc(self,method,params):
        self.counter+=1;request=self.counter
        self.process.stdin.write(json.dumps({'jsonrpc':'2.0','id':request,'method':method,'params':params})+'\n');self.process.stdin.flush()
        deadline=time.monotonic()+60
        while time.monotonic()<deadline:
            result=self.messages.get(timeout=max(.1,deadline-time.monotonic()))
            if result.get('id')==request:
                if 'error' in result:raise RuntimeError('Cua request failed; inspect its current state')
                return result['result']
        raise TimeoutError('Cua request timed out; inspect delivery before retrying')
    def call(self,name,args):
        result=self.rpc('tools/call',{'name':name,'arguments':args})
        if result.get('isError'):raise RuntimeError('Cua refused '+name)
        return result.get('structuredContent',{})
    def close(self):
        self.process.stdin.close()
        try:self.process.wait(timeout=2)
        except subprocess.TimeoutExpired:self.process.terminate();self.process.wait(timeout=2)

def desktop_cua(job,command):
    client=CuaClient(command)
    try:
        permission=client.call('check_permissions',{'prompt':False})
        if not permission.get('accessibility'):raise RuntimeError('Complete the local Accessibility permission flow')
        client.call('get_guide',{'topic':'overview'});client.call('get_guide',{'topic':'permissions'})
        windows=client.call('list_windows',{'app':job['app']})['windows']
        if job.get('window'):windows=[w for w in windows if w.get('title')==job['window']]
        windows=[w for w in windows if w.get('title')]
        if len(windows)!=1:raise ValueError('Select one exact app window')
        window=windows[0];target={'pid':window['pid'],'window_id':window['window_id'],'session':'jason-automation'}
        roles={'button':'AXButton','textfield':'AXTextField','textarea':'AXTextArea','checkbox':'AXCheckBox'}
        count=0
        for index,step in enumerate(job['steps']):
            state=client.call('get_window_state',{**target,'include_screenshot':False,'tree_format':'elements','max_elements':300,'max_depth':12})
            action=step['action']
            if action=='expect_text':
                if step['text'] not in json.dumps(state,ensure_ascii=False):raise ValueError('Expected application result was not observed')
            else:
                wanted=roles[step['role']]
                matches=[e for e in state.get('elements',[]) if e['role']==wanted and (e.get('label')==step.get('name') or (wanted=='AXTextArea' and not step.get('name')))]
                if len(matches)!=1:raise ValueError('Desktop target is absent or ambiguous at step '+str(index))
                element=matches[0];token=element['element_token'];steps=[]
                if action in ['check','uncheck']:
                    checked=element.get('selected',element.get('value')=='1')
                    if checked!=(action=='check'):steps=[{'tool':'click','args':{'element_token':token}}]
                elif action=='click':steps=[{'tool':'click','args':{'element_token':token}}]
                elif action=='fill':
                    if wanted=='AXTextArea':steps=[{'tool':'set_value','args':{'element_token':token,'value':step['value']}}]
                    else:
                        if step.get('replace',False):steps.append({'tool':'hotkey','args':{'element_token':token,'keys':['cmd' if platform.system()=='Darwin' else 'ctrl','a']}})
                        steps.append({'tool':'type_text','args':{'element_token':token,'text':step['value']}})
                else:raise ValueError('Unsupported desktop action')
                if steps:
                    result=client.call('run_steps',{**target,'delivery_mode':'background','foreground_fallback':False,'steps':steps,'observe':{'include_screenshot':False}})
                    if not result.get('ok'):raise RuntimeError('Desktop delivery was not confirmed; inspect before retrying')
            count+=1
        return {'type':'desktop.workflow','driver':'cua','applied':True,'verified':True,'steps_completed':count}
    finally:client.close()

def desktop(job,apply=False,tool=None,cua_command=None,headed=False):
    validate_workflow(job,'desktop')
    if job.get('driver') not in [None,'cua','agent-desktop']:raise ValueError('Unknown desktop driver')
    if not job.get('steps') or job['steps'][-1]['action']!='expect_text':raise ValueError('End with an explicit application-result assertion')
    if not apply:return {'type':'desktop.workflow','applied':False,'app':job['app'],'steps':len(job['steps'])}
    if job.get('driver')=='cua':return desktop_cua(job,cua_command or command_for('cua-driver'))
    executable=command_for('agent-desktop',tool)
    session='jason-'+uuid.uuid4().hex[:12];scope=['--session',session,'--app',job['app']]
    if job.get('window_id'):scope+=['--window-id',str(job['window_id'])]
    cli_json(executable,['status'])
    for guide in ['desktop','platform']:cli_json(executable,['skills','get',guide])
    if headed:cli_json(executable,['focus-window',*scope,'--headed'])
    def references(value):
        found=[]
        if isinstance(value,dict):
            for key,item in value.items():
                if key in ('ref','ref_id') and isinstance(item,str) and item.startswith('@'):found.append(item)
                else:found+=references(item)
        elif isinstance(value,list):
            for item in value:found+=references(item)
        return list(dict.fromkeys(found))
    for index,step in enumerate(job['steps']):
        if step['action']=='expect_text':
            state=cli_json(executable,['snapshot',*scope,'--compact'])
            if step['text'] not in json.dumps(state,ensure_ascii=False):raise ValueError('Expected application result was not observed')
            continue
        result=cli_json(executable,['find',*scope,'--role',step['role'],'--name',step['name'],'--exact'])
        refs=references(result)
        if len(refs)!=1:raise ValueError('Desktop target is absent or ambiguous at step '+str(index))
        ref=refs[0];mode=['--headed'] if headed else []
        action=step['action']
        if action=='fill':
            if headed:
                cli_json(executable,['click',ref,'--session',session,*mode])
                if step.get('replace',False):cli_json(executable,['press','cmd+a' if platform.system()=='Darwin' else 'ctrl+a','--session',session,*mode])
                cli_json(executable,['type',ref,step['value'],'--session',session,*mode])
            else:cli_json(executable,['set-value',ref,step['value'],'--session',session])
        elif action in ['click','check','uncheck']:cli_json(executable,[action,ref,'--session',session,*mode])
        else:raise ValueError('Unsupported desktop action')
    return {'type':'desktop.workflow','driver':'agent-desktop','applied':True,'verified':True,'steps_completed':len(job['steps'])}

def run_job(job,apply=False,**options):
    kind=job['type']
    if kind=='files.organize':return organize(job,apply)
    if kind=='files.undo':return undo_organize(job,apply)
    if kind=='text.edit':return edit_text(job,apply)
    if kind=='records.update':return update_records(job,apply)
    if kind=='browser.workflow':return browser(job,apply,options.get('browser_command'),options.get('browser_executable'))
    if kind=='desktop.workflow':return desktop(job,apply,options.get('desktop_command'),options.get('cua_command'),options.get('headed',False))
    raise ValueError('Unknown task type')
