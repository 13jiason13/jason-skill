"""Configure routes and run installed task implementations, with explicit readiness."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import setup_tools
import jason

def bootstrap(apply=False,offline_tools=None,desktop_job=None,cua_command=None,owned_desktop_test=None):
    if offline_tools:
        # Platform archive binaries are addressed directly; no PATH or global config changes.
        directory=Path(offline_tools).expanduser().absolute()
        manifest=json.loads((directory/'TOOLS.json').read_text())
        if tuple(manifest['platform'])!=setup_tools.platform_key():raise ValueError('Offline pack does not match this platform')
        commands={}
        for tool in ['agent-browser','agent-desktop']:
            entry=manifest['tools'][tool];path=directory/entry['path']
            if not path.is_file() or path.is_symlink():raise ValueError('Missing offline tool')
            if setup_tools.hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:raise ValueError('Offline binary checksum differs')
            commands[tool]=str(path)
        browser_executable=str(directory/manifest['browser_executable'])
        cua_command=cua_command or str(directory/manifest['cua_command'])
        setup={'mode':'offline-reuse','tools':commands}
    else:
        tools=setup_tools.resolve_tools(setup_tools.ROOT,setup_tools.platform_key(),list(setup_tools.VERSIONS),False,apply)
        browser_executable=None
        setup={'mode':'applied' if apply else 'preview','tools':tools}
        commands={item['tool']:item.get('command') for item in tools if item['status'] in ['found-not-GUI-verified','installed-binary-version-verified']}
    if not apply:return {'setup':setup,'task_checks':'not-run-in-preview','ready':False}
    portable=jason.selftest()
    browser=None
    if commands.get('agent-browser'):
        try:browser=jason.selftest(browser=True,browser_command=commands['agent-browser'],browser_executable=browser_executable)
        except Exception as initial_error:
            if offline_tools:
                browser={'passed':False,'error':str(initial_error),'status':'offline-browser-acceptance-failed-no-download-attempted'}
            else:
                browser={'passed':False,'error':str(initial_error)}
            # First runtime setup is a dependency install, not a GUI readiness claim.
            installed=subprocess.CompletedProcess([],1) if offline_tools else subprocess.run([commands['agent-browser'],'install'],capture_output=True,text=True,timeout=420)
            if installed.returncode:
                browser=browser if offline_tools else {'passed':False,'status':'browser-runtime-installation-failed'}
            else:
                try:browser=jason.selftest(browser=True,browser_command=commands['agent-browser'],browser_executable=browser_executable)
                except Exception as error:browser={'passed':False,'error':str(error)}
    desktop=None
    if desktop_job:
        desktop=jason.selftest(desktop_job=desktop_job,desktop_command=commands.get('agent-desktop'),cua_command=cua_command)
    if owned_desktop_test:
        import desktop_acceptance
        try:desktop=desktop_acceptance.run(owned_desktop_test,commands.get('agent-desktop'))
        except Exception as error:desktop={'passed':False,'error':str(error)}
    report={'setup':setup,'portable_acceptance':portable,'browser_acceptance':browser,
            'desktop_acceptance':desktop or {'status':'complete-local-permissions-and-owned-window-test'},
            'ready':bool(browser and browser.get('all_requested_checks_passed') and desktop and (desktop.get('all_requested_checks_passed') or desktop.get('passed'))),
            'optional_cua':{'command_present':bool(cua_command),'accepted':False,'status':'optional-route-needs-separate-acceptance'},
            'host_connection':'Task runner uses direct tool commands; no global MCP edits are required.',
            'note':'Ready requires actual browser and desktop acceptance. Installation alone does not prove UI readiness.'}
    config=Path.home()/'.local/share/jason-skill/runtime.json'
    config.parent.mkdir(parents=True,exist_ok=True)
    # Store command paths, not accounts, cookies or form content.
    config.write_text(json.dumps({'commands':commands,'cua_command':cua_command,'browser_executable':browser_executable},indent=2));config.chmod(0o600)
    return report

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--apply',action='store_true')
    parser.add_argument('--owned-desktop-test');parser.add_argument('--offline-tools');parser.add_argument('--desktop-job');parser.add_argument('--cua-command')
    args=parser.parse_args()
    try:result=bootstrap(args.apply,args.offline_tools,args.desktop_job,args.cua_command,args.owned_desktop_test);print(json.dumps(result,indent=2));return 0 if not args.apply or result['ready'] else 2
    except Exception as error:print(json.dumps({'ready':False,'error':str(error)},indent=2));return 1
if __name__=='__main__':sys.exit(main())
