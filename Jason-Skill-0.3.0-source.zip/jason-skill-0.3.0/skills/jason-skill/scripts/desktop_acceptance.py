"""Exercise an owned native test window, then check its real saved result."""
import json,platform,subprocess,tempfile,time
from pathlib import Path
import automation

def run(directory,command):
    executable=automation.command_for('agent-desktop',command)
    status=automation.cli_json(executable,['status'])
    permission=status.get('permissions',{}).get('accessibility',{})
    if permission.get('state')!='granted':
        return {'passed':False,'status':'local-accessibility-permission-required'}
    directory=Path(directory).absolute()
    with tempfile.TemporaryDirectory(prefix='jason-owned-window-') as temporary:
        result=Path(temporary).resolve()/'native-result.json'
        system=platform.system()
        if system=='Darwin':
            launch=[str(directory/'JasonAcceptance.app/Contents/MacOS/JasonAcceptance'),str(result)]
            app='JasonAcceptance'
        elif system=='Windows':
            launch=['powershell.exe','-NoProfile','-File',str(directory/'WindowsForm.ps1'),'-ResultFile',str(result)]
            app='powershell'
        else:return {'passed':False,'status':'native-fixture-not-provided-for-this-platform'}
        process=subprocess.Popen(launch,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            deadline=time.monotonic()+12;window=None
            while time.monotonic()<deadline:
                if process.poll() is not None:raise RuntimeError('Owned window exited; inspect local application/script policy')
                try:data=automation.cli_json(executable,['list-windows','--app',app])
                except RuntimeError as error:
                    if 'APP_NOT_FOUND' in str(error):time.sleep(.1);continue
                    raise
                def collect(value):
                    if isinstance(value,list):
                        return [item for member in value for item in collect(member)]
                    if isinstance(value,dict):
                        found=[value] if value.get('title')=='Jason Skill Parity Test' else []
                        return found+[item for member in value.values() if isinstance(member,(dict,list)) for item in collect(member)]
                    return []
                windows=collect(data)
                if len(windows)==1:window=windows[0];break
                time.sleep(.1)
            if not window:raise RuntimeError('Owned window did not become observable')
            job={'type':'desktop.workflow','app':app,'steps':[
                {'action':'fill','role':'textfield','name':'Test text','value':'Jason acceptance'},
                {'action':'check','role':'checkbox','name':'Enable test'},
                {'action':'click','role':'button','name':'Add one'},
                {'action':'click','role':'button','name':'Save test'},
                {'action':'expect_text','text':'Saved: Jason acceptance'}]}
            identifier=window.get('id') or window.get('window_id')
            if identifier:job['window_id']=identifier
            automation.desktop(job,True,executable,headed=True)
            data=json.loads(result.read_text())
            if data!={'name':'Jason acceptance','enabled':True,'count':1}:raise ValueError('Native saved model differs')
            return {'passed':True,'status':'owned-input-checkbox-click-save-and-file-readback-passed','driver':'agent-desktop'}
        finally:
            if process.poll() is None:process.terminate()
            try:process.wait(timeout=3)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
