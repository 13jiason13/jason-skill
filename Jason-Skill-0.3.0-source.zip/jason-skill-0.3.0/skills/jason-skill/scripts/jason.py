"""Run bundled automation jobs and acceptance checks."""
import argparse
import json
from pathlib import Path
import sys
import tempfile
import time
import automation

KINDS=['files.organize','files.undo','text.edit','records.update','browser.workflow','desktop.workflow']

def selftest(browser=False,desktop_job=None,**options):
    results={}
    with tempfile.TemporaryDirectory(prefix='jason-acceptance-') as temporary:
        root=Path(temporary);source=root/'inbox';source.mkdir();target=root/'archive'
        for name in ['budget.csv','hero.png','brief.txt']:(source/name).write_text('sample: '+name)
        job={'type':'files.organize','source':str(source),'destination':str(target),'rename':{'brief.txt':'project-brief.txt'}}
        assert not automation.run_job(job)['applied'] and len(list(source.iterdir()))==3
        result=automation.run_job(job,True)
        assert result['verified'] and (target/'docs/project-brief.txt').read_text()=='sample: brief.txt'
        automation.run_job({'type':'files.undo','manifest':result['manifest']},True)
        assert len(list(source.iterdir()))==3
        results['files']='passed'
        original=root/'source.txt';original.write_text('Status: draft\nTotal: 120\n')
        output=root/'approved.txt'
        automation.run_job({'type':'text.edit','source':str(original),'output':str(output),'replacements':[{'old':'draft','new':'approved'},{'old':'120','new':'240'}]},True)
        assert output.read_text()=='Status: approved\nTotal: 240\n' and 'draft' in original.read_text()
        results['text']='passed'
        table=root/'projects.csv';table.write_text('id,status,priority,amount\nA,Ready,3,480\nB,Draft,5,900\nC,Ready,5,320\nD,Ready,1,90\n')
        result=automation.run_job({'type':'records.update','source':str(table),'output':str(root/'updated.csv'),'summary':str(root/'summary.json'),'where':{'status':'Ready'},'minimum':{'amount':300},'sort':{'column':'priority','descending':True},'updates':{'status':'Approved'},'id':'id','sum':'amount'},True)
        assert result['selected']==['C','A'] and result['total']=='800'
        results['records']='passed'
        if browser:
            fixture=root/'form.html';fixture.write_text('''<!doctype html><meta charset="utf-8"><label>Name<input aria-label="Name" id="name"></label><label><input type="checkbox" aria-label="Enable test" id="enable">Enable test</label><button onclick="document.querySelector('#result').textContent=document.querySelector('#name').value+' | '+(document.querySelector('#enable').checked?'enabled':'disabled')">Save locally</button><div id="result"></div>''')
            automation.run_job({'type':'browser.workflow','url':fixture.as_uri(),'steps':[{'action':'fill','name':'Name','role':'textbox','value':'Jason acceptance'},{'action':'check','name':'Enable test','role':'checkbox'},{'action':'click','name':'Save locally','role':'button'},{'action':'expect_text','text':'Jason acceptance | enabled'}]},True,**options)
            results['browser']='passed'
        else:results['browser']='not-tested'
    if desktop_job:
        job=json.loads(Path(desktop_job).read_text(encoding='utf-8'))
        assert job['type']=='desktop.workflow'
        automation.run_job(job,True,**options);results['desktop']='passed-for-supplied-job'
    else:results['desktop']='needs-owned-window-acceptance'
    return {'checks':results,'all_requested_checks_passed':True,
            'all_capabilities_ready':browser and bool(desktop_job),
            'note':'A passed desktop job verifies that job and target only. Host tools, sign-ins and system grants belong to this computer.'}

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--browser-command');parser.add_argument('--browser-executable');parser.add_argument('--desktop-command');parser.add_argument('--cua-command')
    parser.add_argument('--headed',action='store_true',help='Allow the authorized desktop workflow to take foreground focus')
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('capabilities')
    run=sub.add_parser('run');run.add_argument('job',type=Path);run.add_argument('--apply',action='store_true')
    check=sub.add_parser('selftest');check.add_argument('--browser',action='store_true');check.add_argument('--desktop-job')
    args=parser.parse_args(argv)
    options={name:getattr(args,name) for name in ['browser_command','browser_executable','desktop_command','cua_command','headed']}
    started=time.perf_counter()
    try:
        if args.command=='capabilities':result={'version':'0.3.0','bundled_task_types':KINDS,'default_mode':'preview','external_routes':['agent-browser','agent-desktop','optional Cua'],'host_computer_use':'provided by the host; not included as a binary'}
        elif args.command=='selftest':result=selftest(args.browser,args.desktop_job,**options)
        else:
            job=json.loads(args.job.read_text(encoding='utf-8'))
            result=automation.run_job(job,args.apply,**options)
        print(json.dumps({'ok':True,'result':result,'elapsed_seconds':time.perf_counter()-started},indent=2))
        return 0
    except Exception as error:
        print(json.dumps({'ok':False,'error':str(error),'instruction':'Inspect the actual result before retrying a workflow that may have written data.'},indent=2))
        return 1

if __name__=='__main__':sys.exit(main())
