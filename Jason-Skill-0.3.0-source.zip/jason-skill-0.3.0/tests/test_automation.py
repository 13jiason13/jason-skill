import csv,io,json,os,stat,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'skills/jason-skill/scripts'))
import automation

class AutomationTests(unittest.TestCase):
 def test_real_organize_preview_apply_and_undo_preserve_bytes_and_metadata(self):
  with tempfile.TemporaryDirectory() as temporary:
   base=Path(temporary).resolve();source=base/'input';source.mkdir();target=base/'output'
   for name in ['budget.csv','hero.png','brief.txt']:(source/name).write_text(name)
   original=source/'brief.txt';original.chmod(0o640);os.utime(original,ns=(1609459200000000000,1609459200000000000))
   job={'type':'files.organize','source':str(source),'destination':str(target),'rename':{'brief.txt':'project-brief.txt'}}
   self.assertFalse(automation.run_job(job)['applied']);self.assertFalse(target.exists())
   result=automation.run_job(job,True);moved=target/'docs/project-brief.txt'
   self.assertEqual(moved.read_text(),'brief.txt');self.assertEqual(moved.stat().st_mtime_ns,1609459200000000000)
   automation.run_job({'type':'files.undo','manifest':result['manifest']},True)
   self.assertEqual(original.read_text(),'brief.txt');self.assertEqual(original.stat().st_mtime_ns,1609459200000000000)
   if os.name!='nt':self.assertEqual(stat.S_IMODE(original.stat().st_mode),0o640)
 def test_symlink_and_file_groups_and_root_refuse_before_moving(self):
  with tempfile.TemporaryDirectory() as temporary:
   base=Path(temporary).resolve();source=base/'in';source.mkdir();(source/'a.txt').write_text('keep')
   target=base/'out';target.mkdir();(target/'docs').write_text('block')
   job={'type':'files.organize','source':str(source),'destination':str(target)}
   for apply in [False,True]:
    with self.assertRaises(ValueError):automation.run_job(job,apply)
   (target/'docs').unlink();outside=base/'outside';outside.mkdir()
   try:(target/'docs').symlink_to(outside,target_is_directory=True)
   except (OSError,NotImplementedError):pass
   else:
    for apply in [False,True]:
     with self.assertRaises(ValueError):automation.run_job(job,apply)
    (target/'docs').unlink()
   blocker=base/'blocker';blocker.write_text('block')
   for apply in [False,True]:
    with self.assertRaises(ValueError):automation.run_job({**job,'destination':str(blocker)},apply)
   self.assertEqual((source/'a.txt').read_text(),'keep');self.assertFalse(list(outside.iterdir()))
 def test_duplicate_names_are_rejected_with_no_moves(self):
  with tempfile.TemporaryDirectory() as temporary:
   root=Path(temporary).resolve();source=root/'in';source.mkdir()
   for name in ['a.txt','b.txt']:(source/name).write_text(name)
   job={'type':'files.organize','source':str(source),'destination':str(root/'out'),'rename':{'a.txt':'same.txt','b.txt':'same.txt'}}
   with self.assertRaises(FileExistsError):automation.run_job(job,True)
   self.assertEqual(len(list(source.iterdir())),2)
 def test_text_count_failure_writes_nothing_and_success_preserves_crlf(self):
  with tempfile.TemporaryDirectory() as temporary:
   root=Path(temporary).resolve();source=root/'original';source.write_bytes(b'Status: draft\r\nTotal: 120\r\n')
   job={'type':'text.edit','source':str(source),'output':str(root/'new'),'replacements':[{'old':'draft','new':'approved','expected_count':2}]}
   with self.assertRaises(ValueError):automation.run_job(job,True)
   self.assertFalse((root/'new').exists());job['replacements'][0]['expected_count']=1;automation.run_job(job,True)
   self.assertEqual((root/'new').read_bytes(),b'Status: approved\r\nTotal: 120\r\n');self.assertIn(b'draft',source.read_bytes())
 def test_csv_selection_decimal_summary_and_explicit_order(self):
  with tempfile.TemporaryDirectory() as temporary:
   root=Path(temporary).resolve();source=root/'in.csv';source.write_text('id,status,priority,amount\nA,Ready,2,480.50\nB,Draft,5,900\nC,Ready,4,320.25\nD,Ready,1,90\n')
   job={'type':'records.update','source':str(source),'output':str(root/'out.csv'),'summary':str(root/'summary.json'),'where':{'status':'Ready'},'minimum':{'amount':300},'sort':{'column':'priority','descending':True},'sort_output':True,'updates':{'status':'Approved'},'id':'id','sum':'amount'}
   result=automation.run_job(job,True);self.assertEqual(result['selected'],['C','A']);self.assertEqual(result['total'],'800.75')
   with (root/'out.csv').open(newline='') as file:rows=list(csv.DictReader(file))
   self.assertEqual([row['id'] for row in rows],['B','C','A','D']);self.assertIn('A,Ready',source.read_text())
 def test_csv_identifier_updates_rejected(self):
  with tempfile.TemporaryDirectory() as temporary:
   root=Path(temporary).resolve();(root/'in.csv').write_text('id,status,amount\nA,Ready,1\nB,Ready,2\n')
   job={'type':'records.update','source':str(root/'in.csv'),'output':str(root/'out'),'summary':str(root/'summary'),'updates':{'id':'X'},'id':'id','sum':'amount'}
   for apply in [False,True]:
    with self.assertRaises(ValueError):automation.run_job(job,apply)
   self.assertFalse((root/'out').exists())
 def test_bad_gui_recipes_are_rejected_before_running_any_tool(self):
  for kind in ['browser.workflow','desktop.workflow']:
   job={'type':kind,'app':'Test','url':'https://example.com','steps':[{'action':'click','name':'Submit','role':'button'},{'action':'shell','value':'unexpected'},{'action':'expect_text','text':'Saved'}]}
   with patch.object(automation,'cli_json') as call:
    with self.assertRaises(ValueError):automation.run_job(job,True)
    call.assert_not_called()
 def test_empty_expectation_is_not_evidence(self):
  job={'type':'browser.workflow','url':'https://example.com','steps':[{'action':'expect_text','text':''}]}
  with self.assertRaises(ValueError):automation.run_job(job,True)

if __name__=='__main__':unittest.main()
