"""Build a readable, self-contained file for forwarding and Codex installation."""
import hashlib
import json
from pathlib import Path
from install_bundle import ALLOWED

ROOT = Path(__file__).resolve().parent.parent


def build():
    skill = ROOT / "skills/jason-skill"
    files = {}
    for name in sorted(ALLOWED):
        path = ROOT / "LICENSE" if name == "LICENSE" else skill / name
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents if parent != ROOT):
            raise ValueError("Refusing symlink in release input: " + name)
        content = path.read_text(encoding="utf-8")
        files[name] = {"text": content, "sha256": hashlib.sha256(content.encode("utf-8")).hexdigest()}
    installer = (ROOT / "tools/install_bundle.py").read_text(encoding="utf-8")
    payload = {"format": 1, "name": "jason-skill", "version": "0.3.0", "files": files}
    header = """# Jason Skill 0.3.0 — single-file installer

Attach this file to Codex with local file and terminal tools, then ask: Install Jason Skill and configure the tools I need.

Python 3.8+ is required. On Windows, use py -3 instead of python3 when appropriate.

For the receiving agent:
1. Inspect the installer and JSON manifest.
2. Save the Python code block as a temporary install_bundle.py, then run python3 install_bundle.py <this-file>.
3. Default location: ~/.agents/skills/jason-skill. Inspect existing installations in the host's skill directories and use --skills-root if needed. Updating with --replace preserves a backup outside the scanned skill directory.
4. Read the installed SKILL.md and run scripts/doctor.py. Report skill installation and functional tool readiness separately.
5. For the recommended full offline pack, run its Install.command (Mac) or Install.cmd (Windows). The pack supplies Python, Chromium and all three open-source tool binaries. For a source-only install, preview scripts/bootstrap.py, then run --apply with the requested local acceptance target. Add --browser-runtime for Chrome for Testing and --include-cua for optional Cua. Reuse available host tools where appropriate. Use --pinned for the distribution versions in their dedicated directories.
6. Read references/automation.md for the six bundled task types and call scripts/jason.py with the reviewed job. Follow references/portable-install.md and verify the local browser, native form, and files with synthetic data. System grants and account access belong to the recipient. Windows desktop operations need a signed-in interactive session.

Validate this entire file against the checksum from a trusted release. Embedded hashes detect corruption but do not authenticate a publisher.

## Readable installer

"""
    text = header + "```python\n" + installer + "```\n\n## Complete skill payload (UTF-8)\n\n"
    text += "```json jason-skill-bundle\n" + json.dumps(payload, ensure_ascii=False, indent=2) + "\n```\n"
    out = ROOT / "dist"
    out.mkdir(exist_ok=True)
    path = out / "Jason-Skill-0.3.0-install.txt"
    path.write_bytes(text.encode("utf-8"))
    (out / "SHA256SUMS.txt").write_text(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.name + "\n")
    return path


if __name__ == "__main__":
    print(build())
