"""Assemble complete per-platform offline packs from locked official inputs."""
import argparse,hashlib,json,os,shutil,stat,tarfile,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent.parent

def unpack(archive,target):
    target.mkdir(parents=True,exist_ok=True)
    if archive.name.endswith('.tar.gz'):
        with tarfile.open(archive) as tar:tar.extractall(target,filter='data')
    elif archive.suffix=='.zip':
        with zipfile.ZipFile(archive) as package:
            for member in package.infolist():
                name=PurePosixPath(member.filename)
                if name.is_absolute() or '..' in name.parts or '\\' in member.filename:raise ValueError('Unsafe vendor archive')
                path=target/str(name)
                if member.is_dir():path.mkdir(parents=True,exist_ok=True);continue
                path.parent.mkdir(parents=True,exist_ok=True)
                mode=member.external_attr>>16
                if stat.S_ISLNK(mode):
                    link=package.read(member).decode()
                    resolved=(path.parent/link).resolve()
                    if target.resolve() not in resolved.parents:raise ValueError('Vendor symlink escapes')
                    path.symlink_to(link)
                else:
                    with package.open(member) as source,path.open('wb') as output:shutil.copyfileobj(source,output)
                    if mode:path.chmod(mode & 0o777)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--cache',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--platform',action='append');parser.add_argument('--stage-only',action='store_true');parser.add_argument('--archive-existing',action='store_true');args=parser.parse_args()
    lock=json.loads((ROOT/'tools/vendor-lock.json').read_text());args.output.mkdir(parents=True,exist_ok=True)
    for label in args.platform or list(lock):
        item=lock[label];system,arch=item['platform'];name='Jason-Skill-0.3.0-'+label
        pack=args.output/name
        if pack.exists() and args.archive_existing:
            if not (pack/'PACK.json').is_file():raise ValueError('Existing staging has no integrity manifest')
            output=args.output/(name+('.tar.gz' if system=='Darwin' else '.zip'))
            if system=='Darwin':
                with tarfile.open(output,'w:gz',compresslevel=3) as tar:tar.add(pack,arcname=name)
            else:
                with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as package:
                    for path in pack.rglob('*'):
                        if path.is_file():package.write(path,arcname=str(Path(name)/path.relative_to(pack)))
            print(json.dumps({'built':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}),flush=True)
            continue
        if pack.exists():raise FileExistsError('Remove reviewed build staging before rebuilding '+label)
        pack.mkdir();tools=pack/'tools';tools.mkdir();commands={}
        for asset in item['assets']:
            source=args.cache/asset['file']
            if hashlib.sha256(source.read_bytes()).hexdigest()!=asset['sha256']:raise ValueError('Vendor input hash differs')
            kind=asset['kind']
            if kind=='python':unpack(source,pack/'runtime')
            elif kind=='agent-browser':
                destination=tools/'agent-browser'/('agent-browser.exe' if system=='Windows' else 'agent-browser')
                destination.parent.mkdir();shutil.copy2(source,destination);destination.chmod(0o755)
                commands[kind]={'path':destination.relative_to(tools).as_posix(),'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'version':'0.43.0'}
            elif kind=='agent-desktop':
                destination=tools/'agent-desktop';unpack(source,destination)
                binary=destination/('agent-desktop.exe' if system=='Windows' else 'agent-desktop')
                binary.chmod(0o755);commands[kind]={'path':binary.relative_to(tools).as_posix(),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'version':'1.3.1'}
            elif kind=='cua':unpack(source,tools/'cua')
            elif kind=='chromium':unpack(source,tools/'chromium')
        browser=list((tools/'chromium').rglob('chrome.exe')) if system=='Windows' else [p for p in (tools/'chromium').rglob('*') if p.is_file() and p.parent.name=='MacOS' and p.name in ['Chromium','Google Chrome for Testing','Google Chrome']]
        if len(browser)!=1:raise ValueError('Expected one browser executable: '+str(browser))
        cua=list((tools/'cua').rglob('cua-driver.exe' if system=='Windows' else 'cua-driver'))
        cua=[p for p in cua if p.is_file()]
        if system=='Darwin':cua=[p for p in cua if 'CuaDriver.app' in p.parts and p.parent.name=='MacOS']
        if len(cua)!=1:raise ValueError('Expected one Cua executable')
        (tools/'TOOLS.json').write_text(json.dumps({'platform':item['platform'],'tools':commands,'browser_executable':browser[0].relative_to(tools).as_posix(),'cua_command':cua[0].relative_to(tools).as_posix()},indent=2))
        shutil.copytree(ROOT/'patches',pack/'optional-patches');shutil.copytree(ROOT/'licenses',pack/'licenses');shutil.copy2(ROOT/'LICENSE',pack/'LICENSE')
        shutil.copy2(ROOT/'THIRD-PARTY-NOTICES.md',pack/'THIRD-PARTY-NOTICES.md')
        shutil.copytree(ROOT/'skills/jason-skill',pack/'skill',ignore=shutil.ignore_patterns('__pycache__'))
        (pack/'installer').mkdir();shutil.copy2(ROOT/'tools/install_bundle.py',pack/'installer/install_bundle.py')
        shutil.copy2(ROOT/'tools/offline_install.py',pack/'offline_install.py')
        shutil.copy2(ROOT/'dist/Jason-Skill-0.3.0-install.txt',pack/'Jason-Skill-0.3.0-install.txt')
        shutil.copytree(ROOT/'benchmarks/parity',pack/'acceptance')
        if system=='Darwin':
            fixture=ROOT/'build/acceptance'/arch/'JasonAcceptance.app'
            if not fixture.exists():raise ValueError('Build the native acceptance helper first')
            shutil.copytree(fixture,pack/'acceptance/JasonAcceptance.app')
            (pack/'Install.command').write_text('#!/bin/bash\nset -eu\nPACK_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"\nexec "$PACK_DIR/runtime/python/bin/python3.12" "$PACK_DIR/offline_install.py" "$@"\n')
            (pack/'Jason.command').write_text('#!/bin/bash\nset -eu\nPACK_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"\nexec "$PACK_DIR/runtime/python/bin/python3.12" "$PACK_DIR/skill/scripts/jason.py" "$@"\n')
            (pack/'Install.command').chmod(0o755);(pack/'Jason.command').chmod(0o755)
        else:
            (pack/'Install.cmd').write_text('@echo off\r\n"%~dp0runtime\\python\\python.exe" "%~dp0offline_install.py" %*\r\n')
            (pack/'Jason.cmd').write_text('@echo off\r\n"%~dp0runtime\\python\\python.exe" "%~dp0skill\\scripts\\jason.py" %*\r\n')
        (pack/'START-HERE.txt').write_text('Jason Skill 0.3.0 full platform pack\n\nVerify the release checksum, extract the entire archive, and run Install.command (Mac) or Install.cmd (Windows). The pack contains Python, Chromium, agent-browser, agent-desktop, official optional Cua, task implementations and local acceptance tests. No tool download is needed. Installation copies the pack into a stable user directory. Complete local OS permission prompts. Ready is reported only after actual file, browser and owned-window acceptance. AI model access, host Computer Use and third-party accounts are supplied by the recipient. See the repository for tested scope and licenses.\n')
        manifest={'version':'0.3.0','platform':label,'vendor_inputs':item['assets'],'files':{}}
        for path in sorted(pack.rglob('*')):
            relative=path.relative_to(pack).as_posix()
            if path.is_symlink():manifest['files'][relative]={'symlink':os.readlink(path)}
            elif path.is_file():manifest['files'][relative]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        (pack/'PACK.json').write_text(json.dumps(manifest,indent=2))
        if args.stage_only:print(json.dumps({'staged':str(pack),'files':len(manifest['files'])}),flush=True);continue
        if system=='Darwin':
            output=args.output/(name+'.tar.gz')
            with tarfile.open(output,'w:gz',compresslevel=3) as tar:tar.add(pack,arcname=name)
        else:
            output=args.output/(name+'.zip')
            with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as package:
                for path in pack.rglob('*'):
                    if path.is_file():package.write(path,arcname=str(Path(name)/path.relative_to(pack)))
        print(json.dumps({'built':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}),flush=True)
if __name__=='__main__':main()
