"""Release-builder utility: download the reviewed vendor inputs, never user data."""
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,hashlib,json,os
from pathlib import Path
from urllib.request import Request,urlopen
ROOT=Path(__file__).resolve().parent.parent

def download(asset,cache):
    path=cache/asset['file'];expected=asset.get('sha256')
    if path.exists():
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        if not expected or actual==expected:return actual
        raise ValueError('Cached input has an unexpected hash: '+asset['file'])
    staged=path.with_suffix(path.suffix+'.partial')
    if staged.exists():staged.unlink()
    digest=hashlib.sha256();total=0
    request=Request(asset['url'],headers={'User-Agent':'Jason-Skill-release-builder'})
    try:
        with urlopen(request,timeout=45) as response,staged.open('xb') as output:
            while True:
                data=response.read(1024*1024)
                if not data:break
                total+=len(data)
                if total>400*1024*1024:raise ValueError('Vendor archive exceeds the reviewed size limit')
                digest.update(data);output.write(data)
        actual=digest.hexdigest()
        if expected and actual!=expected:raise ValueError('Vendor hash mismatch: '+asset['file'])
        staged.rename(path)
        print(json.dumps({'downloaded':asset['file'],'bytes':total,'sha256':actual}),flush=True)
        return actual
    finally:
        if staged.exists():staged.unlink()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--cache',type=Path,required=True);parser.add_argument('--platform',action='append');args=parser.parse_args()
    args.cache.mkdir(parents=True,exist_ok=True)
    lock_path=ROOT/'tools/vendor-lock.json';lock=json.loads(lock_path.read_text())
    selected=[lock[name] for name in args.platform] if args.platform else list(lock.values())
    assets={item['file']:item for platform in selected for item in platform['assets']}
    hashes={}
    with ThreadPoolExecutor(max_workers=3) as pool:
        pending={pool.submit(download,item,args.cache):name for name,item in assets.items()}
        for task in as_completed(pending):hashes[pending[task]]=task.result()
    for platform in lock.values():
        for item in platform['assets']:
            if item['file'] in hashes:item['sha256']=hashes[item['file']]
    lock_path.write_text(json.dumps(lock,indent=2))
    print('All vendor inputs are downloaded and locked.',flush=True)
if __name__=='__main__':main()
