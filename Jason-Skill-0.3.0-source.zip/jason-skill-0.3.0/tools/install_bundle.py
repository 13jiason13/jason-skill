"""Install the text bundle using Python's standard library only."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile

NAME = "jason-skill"
ALLOWED = {"SKILL.md", "LICENSE", "agents/openai.yaml", "scripts/doctor.py",
           "references/tools.md", "references/benchmark.md", "scripts/setup_macos.py", "scripts/setup_tools.py", "scripts/setup_all.py", "scripts/setup_windows.py", "references/portable-install.md", "scripts/automation.py", "scripts/jason.py", "scripts/bootstrap.py", "scripts/desktop_acceptance.py", "references/automation.md", "examples/organize-files.json", "examples/edit-report.json", "examples/approve-records.json", "examples/browser-form.json", "examples/desktop-form.json"}


def load_bundle(path):
    text = Path(path).read_text(encoding="utf-8-sig")
    blocks = re.findall(r"(?m)^```json jason-skill-bundle\r?\n([\s\S]*?)^```[ \t]*\r?$", text)
    if len(blocks) != 1:
        raise ValueError("Expected exactly one bundle payload")
    bundle = json.loads(blocks[0])
    if bundle.get("name") != NAME or bundle.get("format") != 1:
        raise ValueError("Unsupported bundle")
    files = bundle.get("files")
    if not isinstance(files, dict) or set(files) != ALLOWED:
        raise ValueError("Unexpected or missing file")
    for name, item in files.items():
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts or "\\" in name:
            raise ValueError("Unsafe path")
        content = item["text"]
        if not isinstance(content, str) or len(content.encode("utf-8")) > 200000:
            raise ValueError("Invalid file content")
        if hashlib.sha256(content.encode("utf-8")).hexdigest() != item["sha256"]:
            raise ValueError("Checksum mismatch: " + name)
    if not files["SKILL.md"]["text"].startswith("---\nname: " + NAME + "\n"):
        raise ValueError("Skill identity mismatch")
    return bundle


def matches(target, files):
    if any(p.is_symlink() for p in target.rglob("*")):
        return False
    actual = {p.relative_to(target).as_posix() for p in target.rglob("*") if p.is_file()}
    if actual != set(files):
        return False
    return all(not (target / n).is_symlink() and
               (target / n).read_bytes() == item["text"].encode("utf-8")
               for n, item in files.items())


def install(bundle_path, root=None, replace=False):
    bundle = load_bundle(bundle_path)
    # Current documented Codex user skill directory. No global config edits.
    root = Path(root).expanduser() if root is not None else Path.home() / ".agents/skills"
    root = root.resolve()
    target = root / NAME
    root.mkdir(parents=True, exist_ok=True)
    if target.is_symlink():
        raise ValueError("Target is a symlink; inspect it manually")
    if target.exists():
        if not target.is_dir():
            raise ValueError("Target is not a directory")
        if matches(target, bundle["files"]):
            return {"status": "already-installed", "path": str(target)}
        if not replace:
            raise FileExistsError("Existing skill differs; review it before --replace")
    backup = None
    staging = Path(tempfile.mkdtemp(prefix=".desktop-control-stage-", dir=root.parent))
    try:
        for name, item in bundle["files"].items():
            path = staging / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(item["text"].encode("utf-8"))
            path.chmod(0o644)
        if target.exists():
            backup_root = root.parent / "skill-backups"
            backup_root.mkdir(parents=True, exist_ok=True)
            stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            backup = backup_root / (NAME + "-" + stamp)
            os.rename(target, backup)
        try:
            os.rename(staging, target)
        except BaseException:
            if backup is not None:
                os.rename(backup, target)
            raise
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return {"status": "installed", "path": str(target),
            "backup": str(backup) if backup else None,
            "drivers_installed": False, "global_config_changed": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("bundle", type=Path)
    parser.add_argument("--skills-root", type=Path)
    parser.add_argument("--replace", action="store_true")
    args = parser.parse_args()
    print(json.dumps(install(args.bundle, args.skills_root, args.replace), ensure_ascii=False))


if __name__ == "__main__":
    main()
