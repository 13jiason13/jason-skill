"""Install a complete platform pack into stable user directories, without downloads."""
import argparse,hashlib,json,os,platform,shutil,subprocess,sys,tempfile
from pathlib import Path
PACK=Path(__file__).resolve().parent

def checked(root):
    manifest=json.loads((root/'PACK.json').read_text())
    for name,entry in manifest['files'].items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe pack entry')
        path=root/relative
        if entry.get('symlink') is not None:
            if not path.is_symlink() or os.readlink(path)!=entry['symlink']:raise ValueError('Pack link differs: '+name)
            if root.resolve() not in path.resolve().parents:raise ValueError('Pack link escapes its root')
        elif not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
            raise ValueError('Pack content differs: '+name)
    return manifest

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--skills-root',type=Path)
    parser.add_argument('--verify-only',action='store_true');parser.add_argument('--skip-desktop-test',action='store_true')
    args=parser.parse_args();manifest=checked(PACK)
    if args.verify_only:print(json.dumps({'integrity':'passed','platform':manifest['platform'],'files':len(manifest['files'])}));return 0
    label=manifest['platform'];target=Path.home()/'.local/share/jason-skill/packs/0.3.0'/label
    if target.exists():
        checked(target)
        if (target/'PACK.json').read_bytes()!=(PACK/'PACK.json').read_bytes():
            raise ValueError('An installed pack with this version differs; inspect and back it up before replacement')
    else:
        target.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='.jason-pack-',dir=target.parent) as temporary:
            staging=Path(temporary)/'pack';shutil.copytree(PACK,staging,symlinks=True);checked(staging)
            if target.exists():raise FileExistsError('Pack target appeared during installation')
            os.rename(staging,target)
    if args.skills_root:skills=args.skills_root.expanduser()
    elif (Path.home()/'.codex/skills/jason-skill').exists():skills=Path.home()/'.codex/skills'
    else:skills=Path.home()/'.agents/skills'
    sys.path.insert(0,str(target/'installer'))
    import install_bundle
    installed=install_bundle.install(target/'Jason-Skill-0.3.0-install.txt',skills,replace=True)
    runtime=target/'runtime/python'/('python.exe' if platform.system()=='Windows' else 'bin/python3.12')
    script=skills/'jason-skill/scripts/bootstrap.py'
    command=[str(runtime),str(script),'--apply','--offline-tools',str(target/'tools')]
    if not args.skip_desktop_test:command+=['--owned-desktop-test',str(target/'acceptance')]
    result=subprocess.run(command,text=True,capture_output=True,timeout=180)
    try:acceptance=json.loads(result.stdout)
    except ValueError:acceptance={'ready':False,'error':'Acceptance did not return a result','exit_code':result.returncode}
    print(json.dumps({'pack_installed':str(target),'skill':installed,'acceptance':acceptance,
        'next':'Invoke $jason-skill in the AI host. Complete any local permission or sign-in prompts before using the corresponding function.'},indent=2))
    return 0 if acceptance.get('ready') else 2
if __name__=='__main__':
    try:sys.exit(main())
    except Exception as error:print(json.dumps({'installed':False,'error':str(error)},indent=2));sys.exit(1)
